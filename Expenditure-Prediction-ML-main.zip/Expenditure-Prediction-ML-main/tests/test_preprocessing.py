import sys
from pathlib import Path
import pytest
import pandas as pd
import numpy as np

# Add src_app to path for testing
_SRC_APP = str(Path(__file__).resolve().parent.parent / "src_app")
if _SRC_APP not in sys.path:
    sys.path.insert(0, _SRC_APP)

from utils.preprocessing import load_data, preprocess_pipeline
from utils.prediction import load_artifacts, predict_single

def test_load_data():
    df = load_data()
    assert df is not None
    assert not df.empty
    assert "COST_OF_WORKS_SANCTIONED_LAKHS" in df.columns

def test_preprocess_pipeline():
    X_scaled, y, scaler, df_clean, df_raw = preprocess_pipeline()
    assert X_scaled.shape[0] == y.shape[0]
    assert scaler is not None
    assert len(df_clean) > 0
    assert "PREDICTED_EXPENDITURE_LAKHS" not in df_clean.columns  # Assuming this isn't in clean if it's the target, wait target is EXPENDITURE_OCCURRED_LAKHS
