import sys
from pathlib import Path
import pytest
import numpy as np

# Add src_app to path for testing
_SRC_APP = str(Path(__file__).resolve().parent.parent / "src_app")
if _SRC_APP not in sys.path:
    sys.path.insert(0, _SRC_APP)

from utils.prediction import load_artifacts, predict_single
import config

def test_load_artifacts():
    try:
        artifacts = load_artifacts()
    except FileNotFoundError:
        pytest.skip("Models not trained yet. Run train_models.py first.")
        
    assert "model" in artifacts
    assert "scaler" in artifacts
    assert "metadata" in artifacts
    assert "feature_names" in artifacts

def test_predict_single():
    try:
        artifacts = load_artifacts()
    except FileNotFoundError:
        pytest.skip("Models not trained yet. Run train_models.py first.")
        
    # Create mock input
    mock_input = {feat: 1.0 for feat in artifacts["feature_names"]}
    
    result = predict_single(mock_input, artifacts)
    
    assert "prediction" in result
    assert "category" in result
    assert "color" in result
    assert isinstance(result["prediction"], float)
    assert result["category"] in config.EXPENDITURE_CATEGORIES.keys() or result["category"] == "High"
