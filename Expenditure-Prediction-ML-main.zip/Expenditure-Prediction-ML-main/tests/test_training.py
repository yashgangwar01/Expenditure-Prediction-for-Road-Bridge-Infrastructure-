import sys
from pathlib import Path
import pytest
import numpy as np
from sklearn.datasets import make_regression
from sklearn.model_selection import train_test_split

# Add src_app to path for testing
_SRC_APP = str(Path(__file__).resolve().parent.parent / "src_app")
if _SRC_APP not in sys.path:
    sys.path.insert(0, _SRC_APP)

from utils.training import evaluate_model

def test_evaluate_model():
    # Create mock regression data
    X, y = make_regression(n_samples=100, n_features=10, noise=0.1, random_state=42)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Train a simple model
    from sklearn.linear_model import LinearRegression
    model = LinearRegression()
    model.fit(X_train, y_train)
    
    # Evaluate
    metrics = evaluate_model(model, X_test, y_test)
    
    assert "R2" in metrics
    assert "MAE" in metrics
    assert "RMSE" in metrics
    assert "MAPE" in metrics
    assert metrics["R2"] <= 1.0
