# Road Infrastructure Expenditure Prediction System 🛣️

![Python Version](https://img.shields.io/badge/python-3.9+-blue.svg)
![Streamlit](https://img.shields.io/badge/Streamlit-1.28+-red.svg)
![Scikit-Learn](https://img.shields.io/badge/scikit--learn-1.3+-orange.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)

## Overview

The **Road Infrastructure Expenditure Prediction System** is a machine learning-powered web application designed to forecast the financial expenditure required for road and bridge construction projects. Inspired by rural development schemes like PMGSY in India, this tool assists policymakers, engineers, and project managers in optimizing budget allocations and monitoring financial progress.

It leverages a suite of regression models—including XGBoost, Random Forest, and Gradient Boosting—to provide accurate estimates based on project parameters such as sanctioned lengths, costs, and progress states.

## Features ✨

*   **Interactive Dashboard**: A modern, responsive Streamlit UI for seamless interaction.
*   **Single & Batch Predictions**: Predict expenditure for a single project or upload a CSV for batch processing.
*   **Model Comparison**: Evaluate multiple ML algorithms side-by-side (R², MAE, RMSE, MAPE).
*   **Feature Importance**: Understand what drives predictions using Tree-based feature importance, Permutation Importance, and Partial Dependence Plots (PDP).
*   **Dataset Analysis**: Explore the dataset with interactive Plotly distributions, box plots, and correlation heatmaps.
*   **Session History**: Keep track of your predictions and download reports as CSV.
*   **Production Ready**: Includes centralized logging, robust error handling, Docker configuration, and CI/CD pipelines.

## Repository Structure 📂

```text
Road_Infrastructure_Expenditure_Prediction/
├── app.py/
│   ├── data/                      # Raw Dataset (CSV)
│   ├── logs/                      # Application runtime logs
│   ├── tests/                     # Pytest test suites
│   ├── screenshots/               # Application screenshots
│   ├── .github/workflows/         # CI/CD Pipeline (GitHub Actions)
│   ├── src_app/                   # Main Application Source Code
│   │   ├── app.py                 # Streamlit entry point
│   │   ├── config.py              # Configuration & Constants
│   │   ├── train_models.py        # ML Training Script
│   │   ├── pages/                 # Streamlit Multipages
│   │   ├── utils/                 # Core Helper Modules (ML, Viz, Data)
│   │   └── models/                # Saved ML Artifacts (.joblib, metadata.json)
│   ├── Dockerfile                 # Docker configuration
│   ├── docker-compose.yml         # Docker compose configuration
│   ├── requirements.txt           # Python dependencies
│   └── README.md                  # Project documentation
```

## Getting Started 🚀

### Prerequisites
*   Python 3.9+
*   Git

### Local Installation

1.  **Clone the repository:**
    ```bash
    git clone https://github.com/your-username/road-infra-prediction.git
    cd road-infra-prediction/app.py
    ```

2.  **Install dependencies:**
    ```bash
    pip install -r requirements.txt
    ```

3.  **Train the Machine Learning Models:**
    *Note: You must run this first to generate the necessary `.joblib` artifacts.*
    ```bash
    python src_app/train_models.py
    ```

4.  **Run the Streamlit Application:**
    ```bash
    streamlit run src_app/app.py
    ```

### Docker Deployment 🐳

If you prefer running the application in an isolated container:

1.  **Build and run using Docker Compose:**
    ```bash
    docker-compose up --build
    ```
2.  Open your browser and navigate to `http://localhost:8501`.

## Testing 🧪

This project uses `pytest` for unit testing the data preprocessing, training, and prediction logic.
To run the tests:

```bash
pytest
```

## Screenshots 📸

*(Add screenshots of your application here by saving images into the `screenshots/` directory)*

*   **Dashboard / Home Page**: `screenshots/home.png`
*   **Prediction Page**: `screenshots/prediction.png`
*   **Feature Importance**: `screenshots/feature_importance.png`

## Contributing 🤝
Contributions are welcome! Please feel free to submit a Pull Request.

1.  Fork the Project
2.  Create your Feature Branch (`git checkout -b feature/AmazingFeature`)
3.  Commit your Changes (`git commit -m 'Add some AmazingFeature'`)
4.  Push to the Branch (`git push origin feature/AmazingFeature`)
5.  Open a Pull Request

## License 📄
Distributed under the MIT License. See `LICENSE` for more information.

## Author 👨‍🎓
**Ayush Gupta** (2301140027)
