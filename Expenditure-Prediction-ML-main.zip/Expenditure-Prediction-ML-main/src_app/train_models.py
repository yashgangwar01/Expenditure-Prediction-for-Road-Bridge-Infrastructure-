# -*- coding: utf-8 -*-
"""
train_models.py
---------------
Standalone script to run the full training pipeline, evaluate all
models, and save artifacts to ``src_app/models/``.

Usage:
    python3 train_models.py
"""

import sys
import os
import io
from pathlib import Path

# ── Fix Windows console encoding ──
if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

# ── Ensure src_app is on sys.path ──
_SRC_APP = str(Path(__file__).resolve().parent)
if _SRC_APP not in sys.path:
    sys.path.insert(0, _SRC_APP)

import config
from utils.logger import get_logger
from utils.helpers import ensure_directories
from utils.preprocessing import preprocess_pipeline
from utils.training import train_all_models, save_artifacts

# ── Configure logging ──
logger = get_logger(__name__)


def main() -> None:
    """Execute the full training pipeline."""

    separator = "═" * 60

    print()
    print(separator)
    print("  🛣️  Road Infrastructure Expenditure Prediction System")
    print("  Model Training Pipeline")
    print(separator)
    print()

    # ── 0. Directories ──
    ensure_directories()

    # ── 1. Load & preprocess ──
    print("[1/4] Loading and preprocessing data...")
    print(f"  Dataset: {config.DATASET_PATH.name}")

    X_scaled, y, scaler, df_clean, df_raw = preprocess_pipeline(
        csv_path=str(config.DATASET_PATH)
    )

    # Get feature names from the clean dataframe (minus target)
    feature_names = [c for c in df_clean.columns if c != config.TARGET_COLUMN]

    print(f"  ✓ Raw rows:   {len(df_raw)}")
    print(f"  ✓ Clean rows:  {len(df_clean)}")
    print(f"  ✓ Features:    {len(feature_names)}")
    print()

    # ── 2. Train all models ──
    print("[2/4] Training and tuning models...")
    print("  (This may take a minute with RandomizedSearchCV)")
    print()

    training_output = train_all_models(
        X_scaled=X_scaled,
        y=y,
        feature_names=feature_names,
        models_dir=config.MODELS_DIR,
        tune=True,
    )

    # ── 3. Print results ──
    print()
    print("[3/4] Evaluation Results")
    print("─" * 60)
    print(f"  {'Model':<25} {'R²':>8} {'MAE':>10} {'RMSE':>10} {'MAPE%':>8} {'CV R²':>8}")
    print("─" * 60)

    results = training_output["results"]
    best_name = training_output["best_model_name"]

    for name, data in results.items():
        m = data["metrics"]
        cv = data["cv"]
        marker = "  ★" if name == best_name else "   "
        print(
            f"{marker} {name:<24} {m['R2']:>8.4f} {m['MAE']:>10.2f} "
            f"{m['RMSE']:>10.2f} {m['MAPE']:>7.2f}% {cv['cv_mean']:>8.4f}"
        )

    print("─" * 60)
    print(f"\n  ★ Best Model: {best_name}  (R² = {results[best_name]['metrics']['R2']:.4f})")
    print()

    # ── 4. Save artifacts ──
    print("[4/4] Saving artifacts...")
    save_artifacts(training_output, scaler, config.MODELS_DIR)

    print()
    print(separator)
    print("  ✅  Training Complete!")
    print(f"  Artifacts saved to: {config.MODELS_DIR}")
    print(separator)
    print()


if __name__ == "__main__":
    main()
