import pandas as pd
import numpy as np
import os
import joblib

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler, PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.svm import SVR
from sklearn.metrics import r2_score

# Defines the features we expect from the raw dataset based on project file.py
NUMERIC_COLS = [
    'NO_OF_ROAD_WORK_SANCTIONED',
    'NO_OF_BRIDGES_SANCTIONED',
    'NO_OF_ROAD_WORKS_COMPLETED',
    'NO_OF_BRIDGES_COMPLETED',
    'NO_OF_ROAD_WORKS_BALANCE',
    'NO_OF_BRIDGES_BALANCE',
    'LENGTH_OF_ROAD_WORK_SANCTIONED_KM',
    'COST_OF_WORKS_SANCTIONED_LAKHS',
    'LENGTH_OF_ROAD_WORK_COMPLETED_KM',
    'LENGTH_OF_ROAD_WORK_BALANCE_KM',
    'EXPENDITURE_OCCURED_LAKHS'
]

def load_data(csv_path):
    """Loads the dataset and selects only the required numeric columns."""
    df = pd.read_csv(csv_path)
    cols_to_use = [c for c in NUMERIC_COLS if c in df.columns]
    df = df[cols_to_use]
    return df

def preprocess_data(df, is_training=True):
    """
    Applies median imputation and IQR-based outlier removal (if training).
    Returns the cleaned dataframe.
    """
    df.fillna(df.median(), inplace=True)
    
    if is_training:
        for col in df.columns:
            Q1 = df[col].quantile(0.25)
            Q3 = df[col].quantile(0.75)
            IQR = Q3 - Q1
            lower = Q1 - 1.5 * IQR
            upper = Q3 + 1.5 * IQR
            df = df[(df[col] >= lower) & (df[col] <= upper)]
            
    return df

def get_features_and_target(df):
    """Splits dataframe into features X and target y."""
    X = df.drop('EXPENDITURE_OCCURED_LAKHS', axis=1)
    y = df['EXPENDITURE_OCCURED_LAKHS']
    return X, y

def train_and_evaluate_models(X_train, X_test, y_train, y_test):
    """Trains multiple regression models and evaluates them."""
    models = {
        "Linear Regression": LinearRegression(),
        "Decision Tree Regression": DecisionTreeRegressor(random_state=42),
        "KNN Regression": KNeighborsRegressor(n_neighbors=5),
        "SVR Regression": SVR()
    }
    
    results = {}
    best_r2 = -float("inf")
    best_model_name = ""
    best_model = None
    
    for name, model in models.items():
        model.fit(X_train, y_train)
        preds = model.predict(X_test)
        r2 = r2_score(y_test, preds)
        results[name] = r2
        if r2 > best_r2:
            best_r2 = r2
            best_model_name = name
            best_model = model
            
    return best_model, best_model_name, results

def run_pipeline(dataset_path, models_dir):
    """Runs the full pipeline, saves scaler and best model, and returns evaluation stats."""
    os.makedirs(models_dir, exist_ok=True)
    
    print("Loading data...")
    df = load_data(dataset_path)
    
    print("Preprocessing data...")
    df = preprocess_data(df, is_training=True)
    
    X, y = get_features_and_target(df)
    
    print("Scaling features...")
    scaler = MinMaxScaler()
    X_scaled = scaler.fit_transform(X)
    
    scaler_path = os.path.join(models_dir, "scaler.joblib")
    joblib.dump(scaler, scaler_path)
    print(f"Scaler saved to {scaler_path}")
    
    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=0.2, random_state=42
    )
    
    print("Training standard models...")
    best_model, best_model_name, results = train_and_evaluate_models(X_train, X_test, y_train, y_test)
    
    # Polynomial Regression evaluation
    poly = PolynomialFeatures(degree=2)
    X_poly = poly.fit_transform(X_scaled)
    Xp_train, Xp_test, yp_train, yp_test = train_test_split(
        X_poly, y, test_size=0.2, random_state=42
    )
    pr = LinearRegression()
    pr.fit(Xp_train, yp_train)
    poly_preds = pr.predict(Xp_test)
    poly_r2 = r2_score(yp_test, poly_preds)
    results["Polynomial Regression"] = poly_r2
    
    # Check if poly is better (for deployment, poly requires saving PolynomialFeatures too,
    # to keep inference simple we will prefer standard models unless poly is massively better.
    # We'll save the best standard model).
    
    # For now, save the best standard model since it supports direct predictions on X_scaled.
    model_path = os.path.join(models_dir, "best_model.joblib")
    joblib.dump(best_model, model_path)
    print(f"\nBest deployable model ({best_model_name}) saved to {model_path}")
    
    print("\nModel R2 Scores:")
    for m, score in results.items():
        print(f"{m}: {score:.4f}")
        
    return results

if __name__ == "__main__":
    # The workspace URI is `c:\Users\Ayush Gupta\OneDrive\Desktop\predictive analysis\app.py`
    # The dataset is in `c:\Users\Ayush Gupta\OneDrive\Desktop\predictive analysis\predictive project dataset.csv`
    # The dataset is in the parent of the parent directory (predictive analysis)
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) 
    dataset_path = os.path.join(base_dir, "data", "predictive project dataset.csv")
    models_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")
    
    print(f"Dataset path resolved to: {dataset_path}")
    run_pipeline(dataset_path, models_dir)
