"""
logger.py
---------
Centralized logging configuration for the Road Infrastructure Expenditure Prediction System.
Logs are written to both the console and a rotating file in logs/app.log.
"""

import logging
import sys
from pathlib import Path

_APP_ROOT = Path(__file__).resolve().parent.parent.parent
LOGS_DIR = _APP_ROOT / "logs"
LOG_FILE = LOGS_DIR / "app.log"

def get_logger(name: str) -> logging.Logger:
    """
    Returns a configured logger instance.
    
    Args:
        name: Name of the logger (usually __name__).
        
    Returns:
        logging.Logger: Configured logger.
    """
    # Create logs directory if it doesn't exist
    LOGS_DIR.mkdir(parents=True, exist_ok=True)
    
    logger = logging.getLogger(name)
    
    # Only configure if not already configured to avoid duplicate handlers
    if not logger.handlers:
        logger.setLevel(logging.INFO)
        
        # Formatter
        formatter = logging.Formatter(
            fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        
        # File Handler
        file_handler = logging.FileHandler(LOG_FILE, encoding="utf-8")
        file_handler.setLevel(logging.INFO)
        file_handler.setFormatter(formatter)
        
        # Console Handler
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.INFO)
        console_handler.setFormatter(formatter)
        
        # Add Handlers
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)
        
    return logger
