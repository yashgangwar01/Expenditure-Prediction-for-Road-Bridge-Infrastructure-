"""
helpers.py
──────────
General-purpose helper utilities: path resolution, JSON I/O,
currency formatting, timestamp generation, and directory setup.
"""

import json
import logging
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

# ── Ensure src_app is on sys.path for absolute imports ──
_SRC_APP = str(Path(__file__).resolve().parent.parent)
if _SRC_APP not in sys.path:
    sys.path.insert(0, _SRC_APP)

import config  # noqa: E402

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════
#  LOGGING
# ═══════════════════════════════════════════════════

def setup_logging(level: str = "INFO") -> None:
    """Configure root logger with a clean console format."""
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s │ %(levelname)-8s │ %(name)s │ %(message)s",
        datefmt="%H:%M:%S",
    )


# ═══════════════════════════════════════════════════
#  DIRECTORY MANAGEMENT
# ═══════════════════════════════════════════════════

def ensure_directories() -> None:
    """Create required output directories if they do not exist."""
    for d in (config.MODELS_DIR, config.ASSETS_DIR, config.REPORTS_DIR):
        d.mkdir(parents=True, exist_ok=True)
        logger.debug("Directory ensured: %s", d)


# ═══════════════════════════════════════════════════
#  JSON I/O
# ═══════════════════════════════════════════════════

def load_json(path: Path) -> Dict[str, Any]:
    """Load and return a JSON file as a dictionary.

    Args:
        path: Absolute or relative path to the JSON file.

    Returns:
        Parsed dictionary from the JSON content.

    Raises:
        FileNotFoundError: If the file does not exist.
        json.JSONDecodeError: If the content is not valid JSON.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"JSON file not found: {path}")
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_json(data: Any, path: Path) -> None:
    """Serialize *data* to a pretty-printed JSON file.

    Args:
        data: Any JSON-serializable Python object.
        path: Target file path (parent dirs are created automatically).
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, default=str)
    logger.debug("Saved JSON → %s", path)


# ═══════════════════════════════════════════════════
#  FORMATTING
# ═══════════════════════════════════════════════════

def format_currency(value: float, prefix: str = "₹", suffix: str = " Lakhs") -> str:
    """Format a numeric value as Indian-style currency.

    Examples:
        >>> format_currency(1234.5)
        '₹ 1,234.50 Lakhs'
    """
    return f"{prefix} {value:,.2f}{suffix}"


def format_number(value: float, decimals: int = 2) -> str:
    """Format a number with thousand separators.

    Examples:
        >>> format_number(98765.4321)
        '98,765.43'
    """
    return f"{value:,.{decimals}f}"


def format_percentage(value: float, decimals: int = 2) -> str:
    """Convert a fraction (0-1) to a percentage string.

    Examples:
        >>> format_percentage(0.9234)
        '92.34%'
    """
    return f"{value * 100:.{decimals}f}%"


# ═══════════════════════════════════════════════════
#  TIMESTAMPS
# ═══════════════════════════════════════════════════

def get_timestamp() -> str:
    """Return the current UTC timestamp in ISO 8601 format."""
    return datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")


def get_readable_timestamp() -> str:
    """Return a human-readable local timestamp."""
    return datetime.now().strftime("%d %B %Y, %I:%M %p")
