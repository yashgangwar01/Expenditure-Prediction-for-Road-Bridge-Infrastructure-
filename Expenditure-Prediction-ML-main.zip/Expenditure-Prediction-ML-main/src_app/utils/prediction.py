"""
prediction.py
─────────────
Inference utilities: load saved artifacts, make single and batch
predictions, and categorise expenditure levels.
"""

import logging
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import joblib
import numpy as np
import pandas as pd

# ── Ensure src_app is on sys.path ──
_SRC_APP = str(Path(__file__).resolve().parent.parent)
if _SRC_APP not in sys.path:
    sys.path.insert(0, _SRC_APP)

import config  # noqa: E402
from utils.helpers import load_json  # noqa: E402

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════
#  ARTIFACT LOADING
# ═══════════════════════════════════════════════════

def load_artifacts(
    models_dir: Optional[Path] = None,
) -> Dict[str, Any]:
    """Load all saved model artifacts needed for inference.

    Returns:
        Dictionary with keys:
            ``model``          — Best fitted model.
            ``scaler``         — Fitted MinMaxScaler.
            ``feature_names``  — Ordered list of feature names.
            ``metadata``       — Training metadata dict.
            ``all_models``     — Dict of all fitted models (or None).
            ``polynomial``     — PolynomialFeatures transformer (or None).
    """
    models_dir = Path(models_dir) if models_dir else config.MODELS_DIR

    if not models_dir.exists():
        raise FileNotFoundError(
            f"Models directory not found: {models_dir}.  "
            "Run train_models.py first."
        )

    artifacts: Dict[str, Any] = {}

    # Required
    artifacts["model"] = joblib.load(models_dir / "best_model.joblib")
    artifacts["scaler"] = joblib.load(models_dir / "scaler.joblib")
    artifacts["feature_names"] = load_json(models_dir / "feature_names.json")
    artifacts["metadata"] = load_json(models_dir / "metadata.json")

    # Optional
    all_models_path = models_dir / "all_models.joblib"
    if all_models_path.exists():
        artifacts["all_models"] = joblib.load(all_models_path)
    else:
        artifacts["all_models"] = None

    poly_path = models_dir / "polynomial.joblib"
    if poly_path.exists():
        artifacts["polynomial"] = joblib.load(poly_path)
    else:
        artifacts["polynomial"] = None

    logger.info(
        "Loaded artifacts from %s  (best model: %s)",
        models_dir,
        artifacts["metadata"].get("best_model", "unknown"),
    )
    return artifacts


# ═══════════════════════════════════════════════════
#  SINGLE PREDICTION
# ═══════════════════════════════════════════════════

def predict_single(
    input_values: Dict[str, float],
    artifacts: Dict[str, Any],
) -> Dict[str, Any]:
    """Predict expenditure for a single set of input features.

    Args:
        input_values: Dictionary mapping feature names → numeric values.
                      Must contain all features listed in
                      ``artifacts['feature_names']``.
        artifacts:    Output of ``load_artifacts()``.

    Returns:
        Dictionary with:
            ``prediction``  — Predicted expenditure in Lakhs.
            ``category``    — Expenditure category (Low/Medium/High).
            ``icon``        — Category emoji icon.
            ``color``       — Category hex colour.
            ``input_df``    — The input as a single-row DataFrame.
    """
    feature_names: List[str] = artifacts["feature_names"]
    scaler = artifacts["scaler"]
    model = artifacts["model"]

    # Build ordered feature array
    values = [float(input_values.get(f, 0.0)) for f in feature_names]
    input_df = pd.DataFrame([values], columns=feature_names)

    # Scale
    X_scaled = scaler.transform(input_df)

    # Predict
    prediction = float(model.predict(X_scaled)[0])
    prediction = max(prediction, 0.0)  # expenditure cannot be negative

    # Categorise
    category, icon, color = categorize_expenditure(prediction)

    return {
        "prediction": prediction,
        "category":   category,
        "icon":       icon,
        "color":      color,
        "input_df":   input_df,
    }


# ═══════════════════════════════════════════════════
#  BATCH PREDICTION
# ═══════════════════════════════════════════════════

def predict_batch(
    df: pd.DataFrame,
    artifacts: Dict[str, Any],
) -> pd.DataFrame:
    """Predict expenditure for every row in a DataFrame.

    Missing feature columns are filled with 0.  The original
    DataFrame is returned with two new columns appended:
        ``PREDICTED_EXPENDITURE_LAKHS`` and ``PREDICTION_CATEGORY``.

    Args:
        df:        Input DataFrame (one row per prediction).
        artifacts: Output of ``load_artifacts()``.

    Returns:
        Original DataFrame augmented with prediction columns.
    """
    feature_names: List[str] = artifacts["feature_names"]
    scaler = artifacts["scaler"]
    model = artifacts["model"]

    # Ensure all required columns exist
    df_input = df.copy()
    for f in feature_names:
        if f not in df_input.columns:
            df_input[f] = 0.0
            logger.warning("Missing column '%s' — filled with 0.0", f)

    X = df_input[feature_names].fillna(0.0).values
    X_scaled = scaler.transform(X)
    predictions = model.predict(X_scaled)
    predictions = np.maximum(predictions, 0.0)

    df_input["PREDICTED_EXPENDITURE_LAKHS"] = predictions
    df_input["PREDICTION_CATEGORY"] = [
        categorize_expenditure(p)[0] for p in predictions
    ]

    logger.info("Batch prediction completed: %d rows", len(df_input))
    return df_input


# ═══════════════════════════════════════════════════
#  CATEGORISATION
# ═══════════════════════════════════════════════════

def categorize_expenditure(value: float) -> Tuple[str, str, str]:
    """Map a predicted expenditure value to a category.

    Args:
        value: Predicted expenditure in Lakhs.

    Returns:
        Tuple of ``(category_name, emoji_icon, hex_color)``.
    """
    for cat, (low, high) in config.EXPENDITURE_CATEGORIES.items():
        if low <= value < high:
            return (
                cat,
                config.CATEGORY_ICONS.get(cat, ""),
                config.CATEGORY_COLORS.get(cat, "#FFFFFF"),
            )
    # Fallback for values outside defined ranges
    return ("High", config.CATEGORY_ICONS["High"], config.CATEGORY_COLORS["High"])
