"""
training.py
───────────
Model definitions, hyperparameter grids, training, tuning with
RandomizedSearchCV, cross-validation, and artifact saving.
Reuses the exact model set from ``project file.py`` and extends it
with Random Forest, Gradient Boosting, and XGBoost.
"""

import logging
import sys
import warnings
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import (
    GradientBoostingRegressor,
    RandomForestRegressor,
)
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import (
    RandomizedSearchCV,
    cross_val_score,
    train_test_split,
)
from sklearn.neighbors import KNeighborsRegressor
from sklearn.preprocessing import PolynomialFeatures
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor

# ── Ensure src_app is on sys.path ──
_SRC_APP = str(Path(__file__).resolve().parent.parent)
if _SRC_APP not in sys.path:
    sys.path.insert(0, _SRC_APP)

import config  # noqa: E402
from utils.logger import get_logger  # noqa: E402
from utils.metrics import evaluate_model  # noqa: E402
from utils.helpers import save_json, get_timestamp  # noqa: E402

logger = get_logger(__name__)
warnings.filterwarnings("ignore")


# ═══════════════════════════════════════════════════
#  MODEL REGISTRY
# ═══════════════════════════════════════════════════

def get_models() -> Dict[str, Any]:
    """Return a dictionary of regression model instances.

    The base five models come from ``project file.py``:
        Linear Regression, Decision Tree, KNN, SVR

    Extended models:
        Random Forest, Gradient Boosting, XGBoost (if installed)
    """
    models: Dict[str, Any] = {
        "Linear Regression":       LinearRegression(),
        "Decision Tree":           DecisionTreeRegressor(random_state=config.RANDOM_STATE),
        "KNN Regression":          KNeighborsRegressor(n_neighbors=5),
        "SVR":                     SVR(),
        "Random Forest":           RandomForestRegressor(random_state=config.RANDOM_STATE, n_jobs=-1),
        "Gradient Boosting":       GradientBoostingRegressor(random_state=config.RANDOM_STATE),
    }

    # Attempt XGBoost import
    try:
        from xgboost import XGBRegressor
        models["XGBoost"] = XGBRegressor(
            random_state=config.RANDOM_STATE,
            n_jobs=-1,
            verbosity=0,
        )
        logger.info("XGBoost is available and added to model registry")
    except ImportError:
        logger.warning("XGBoost not installed — skipping")

    return models


def get_param_grids() -> Dict[str, Dict[str, List]]:
    """Hyperparameter grids for RandomizedSearchCV.

    Only models that benefit from tuning are included.
    Linear Regression has no tuneable hyperparameters.
    """
    grids: Dict[str, Dict[str, List]] = {
        "Decision Tree": {
            "max_depth":         [3, 5, 10, 15, None],
            "min_samples_split": [2, 5, 10, 20],
            "min_samples_leaf":  [1, 2, 5, 10],
        },
        "KNN Regression": {
            "n_neighbors": [3, 5, 7, 9, 11, 15],
            "weights":     ["uniform", "distance"],
            "metric":      ["minkowski", "manhattan"],
        },
        "SVR": {
            "C":      [0.1, 1, 10, 100],
            "kernel": ["rbf", "linear"],
            "gamma":  ["scale", "auto"],
            "epsilon":[0.01, 0.1, 0.5],
        },
        "Random Forest": {
            "n_estimators": [50, 100, 200, 300],
            "max_depth":    [5, 10, 15, None],
            "min_samples_split": [2, 5, 10],
        },
        "Gradient Boosting": {
            "n_estimators":  [50, 100, 200],
            "learning_rate": [0.01, 0.05, 0.1, 0.2],
            "max_depth":     [3, 5, 7],
        },
    }

    try:
        from xgboost import XGBRegressor  # noqa: F401
        grids["XGBoost"] = {
            "n_estimators":  [50, 100, 200, 300],
            "learning_rate": [0.01, 0.05, 0.1, 0.2],
            "max_depth":     [3, 5, 7, 10],
            "subsample":     [0.7, 0.8, 1.0],
        }
    except ImportError:
        pass

    return grids


# ═══════════════════════════════════════════════════
#  TRAINING
# ═══════════════════════════════════════════════════

def train_single_model(
    model: Any,
    X_train: np.ndarray,
    y_train: np.ndarray,
) -> Tuple[Any, float]:
    """Fit a single model and return it with training time."""
    start = time.time()
    model.fit(X_train, y_train)
    fit_time = time.time() - start
    return model, fit_time


def tune_model(
    model: Any,
    param_grid: Dict[str, List],
    X_train: np.ndarray,
    y_train: np.ndarray,
    n_iter: int = config.TUNING_N_ITER,
    cv: int = config.CV_FOLDS,
    scoring: str = config.TUNING_SCORING,
) -> Tuple[Any, float]:
    """Tune a model using RandomizedSearchCV.

    Args:
        model:      Unfitted estimator.
        param_grid: Hyperparameter search space.
        X_train:    Training feature matrix.
        y_train:    Training target vector.
        n_iter:     Number of random combinations to try.
        cv:         Cross-validation folds.
        scoring:    Scoring metric.

    Returns:
        Best fitted estimator from the search.
    """
    # Ensure n_iter does not exceed the number of possible combinations
    n_combos = 1
    for v in param_grid.values():
        n_combos *= len(v)
    actual_iter = min(n_iter, n_combos)

    search = RandomizedSearchCV(
        estimator=model,
        param_distributions=param_grid,
        n_iter=actual_iter,
        cv=cv,
        scoring=scoring,
        random_state=config.RANDOM_STATE,
        n_jobs=-1,
        error_score="raise",
    )
    start = time.time()
    search.fit(X_train, y_train)
    fit_time = time.time() - start
    logger.info("  Best params: %s  (CV score: %.4f)", search.best_params_, search.best_score_)
    return search.best_estimator_, fit_time


def cross_validate(
    model: Any,
    X: np.ndarray,
    y: np.ndarray,
    cv: int = config.CV_FOLDS,
    scoring: str = "r2",
) -> Dict[str, float]:
    """Run K-fold cross-validation and return summary stats.

    Returns:
        Dictionary with ``cv_mean``, ``cv_std``, ``cv_scores``.
    """
    scores = cross_val_score(model, X, y, cv=cv, scoring=scoring, n_jobs=-1)
    return {
        "cv_mean":  float(np.mean(scores)),
        "cv_std":   float(np.std(scores)),
        "cv_scores": [float(s) for s in scores],
    }


# ═══════════════════════════════════════════════════
#  FULL TRAINING PIPELINE
# ═══════════════════════════════════════════════════

def train_all_models(
    X_scaled: np.ndarray,
    y: pd.Series,
    feature_names: List[str],
    models_dir: Optional[Path] = None,
    tune: bool = True,
) -> Dict[str, Any]:
    """Train, evaluate, and save all models.

    This is the master function that orchestrates the full training
    pipeline.  It:
        1. Splits data into train/test.
        2. Trains base models (with optional tuning).
        3. Trains Polynomial Regression separately.
        4. Evaluates every model.
        5. Runs cross-validation on each.
        6. Returns a results dictionary.

    Args:
        X_scaled:      Scaled feature matrix.
        y:             Target vector.
        feature_names: Ordered list of feature column names.
        models_dir:    Directory to save model artifacts.
        tune:          Whether to run hyperparameter tuning.

    Returns:
        Dictionary mapping model names to their results, fitted objects,
        and the overall best model name.
    """
    models_dir = Path(models_dir) if models_dir else config.MODELS_DIR
    models_dir.mkdir(parents=True, exist_ok=True)

    # ── Train / test split ──
    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y,
        test_size=config.TEST_SIZE,
        random_state=config.RANDOM_STATE,
    )
    logger.info("Train/test split: %d / %d", len(X_train), len(X_test))

    models = get_models()
    param_grids = get_param_grids() if tune else {}
    results: Dict[str, Dict] = {}

    # ── Standard models ──
    for name, model in models.items():
        logger.info("Training: %s", name)

        if tune and name in param_grids:
            fitted, fit_time = tune_model(model, param_grids[name], X_train, y_train)
        else:
            fitted, fit_time = train_single_model(model, X_train, y_train)

        start = time.time()
        preds = fitted.predict(X_test)
        pred_time = time.time() - start
        
        metrics = evaluate_model(y_test.values, preds)
        cv_info = cross_validate(fitted, X_scaled, y.values)

        results[name] = {
            "model":       fitted,
            "predictions": preds,
            "metrics":     metrics,
            "cv":          cv_info,
            "fit_time":    fit_time,
            "pred_time":   pred_time,
        }
        logger.info(
            "  → R²=%.4f  MAE=%.2f  RMSE=%.2f  MAPE=%.2f%%  CV=%.4f±%.4f",
            metrics["R2"], metrics["MAE"], metrics["RMSE"], metrics["MAPE"],
            cv_info["cv_mean"], cv_info["cv_std"],
        )

    # ── Polynomial Regression ──
    logger.info("Training: Polynomial Regression (degree=%d)", config.POLYNOMIAL_DEGREE)
    poly_transformer = PolynomialFeatures(degree=config.POLYNOMIAL_DEGREE, include_bias=False)
    X_poly_train = poly_transformer.fit_transform(X_train)
    X_poly_test = poly_transformer.transform(X_test)

    poly_model = LinearRegression()
    start = time.time()
    poly_model.fit(X_poly_train, y_train)
    poly_fit_time = time.time() - start
    
    start = time.time()
    poly_preds = poly_model.predict(X_poly_test)
    poly_pred_time = time.time() - start
    
    poly_metrics = evaluate_model(y_test.values, poly_preds)

    # CV for polynomial — need to transform full X
    X_poly_full = poly_transformer.transform(X_scaled)
    poly_cv = cross_validate(poly_model, X_poly_full, y.values)

    results["Polynomial Regression"] = {
        "model":            poly_model,
        "poly_transformer": poly_transformer,
        "predictions":      poly_preds,
        "metrics":          poly_metrics,
        "cv":               poly_cv,
        "fit_time":         poly_fit_time,
        "pred_time":        poly_pred_time,
    }
    logger.info(
        "  → R²=%.4f  MAE=%.2f  RMSE=%.2f  MAPE=%.2f%%  CV=%.4f±%.4f",
        poly_metrics["R2"], poly_metrics["MAE"], poly_metrics["RMSE"],
        poly_metrics["MAPE"], poly_cv["cv_mean"], poly_cv["cv_std"],
    )

    # ── Find best model (by test R²) ──
    best_name = max(results, key=lambda n: results[n]["metrics"]["R2"])
    logger.info("★ Best model: %s  (R² = %.4f)", best_name, results[best_name]["metrics"]["R2"])

    # ── Package output ──
    output = {
        "results":        results,
        "best_model_name": best_name,
        "y_test":         y_test,
        "y_train":        y_train,
        "X_test":         X_test,
        "X_train":        X_train,
        "feature_names":  feature_names,
    }

    # Attach polynomial transformer at top level for easy access
    output["poly_transformer"] = poly_transformer

    return output


# ═══════════════════════════════════════════════════
#  ARTIFACT SAVING
# ═══════════════════════════════════════════════════

def save_artifacts(
    training_output: Dict[str, Any],
    scaler: Any,
    models_dir: Optional[Path] = None,
) -> None:
    """Persist all trained models and metadata to disk.

    Saved files:
        - ``best_model.joblib``   — Best model for inference.
        - ``scaler.joblib``       — Fitted MinMaxScaler.
        - ``polynomial.joblib``   — PolynomialFeatures transformer.
        - ``all_models.joblib``   — Dict of ALL fitted model objects.
        - ``metadata.json``       — Metrics, timestamps, best model info.
        - ``feature_names.json``  — Ordered feature column names.
    """
    models_dir = Path(models_dir) if models_dir else config.MODELS_DIR
    models_dir.mkdir(parents=True, exist_ok=True)

    results = training_output["results"]
    best_name = training_output["best_model_name"]
    feature_names = training_output["feature_names"]

    # 1. Best model
    best_model = results[best_name]["model"]
    joblib.dump(best_model, models_dir / "best_model.joblib")
    logger.info("Saved: best_model.joblib  (%s)", best_name)

    # 2. Scaler
    joblib.dump(scaler, models_dir / "scaler.joblib")
    logger.info("Saved: scaler.joblib")

    # 3. Polynomial transformer
    poly_t = training_output.get("poly_transformer")
    if poly_t is not None:
        joblib.dump(poly_t, models_dir / "polynomial.joblib")
        logger.info("Saved: polynomial.joblib")

    # 4. All models dict (model objects only)
    all_models = {name: data["model"] for name, data in results.items()}
    joblib.dump(all_models, models_dir / "all_models.joblib")
    logger.info("Saved: all_models.joblib  (%d models)", len(all_models))

    # 5. Feature names
    save_json(feature_names, models_dir / "feature_names.json")
    logger.info("Saved: feature_names.json")

    # 6. Metadata
    metrics_summary = {}
    for name, data in results.items():
        metrics_summary[name] = {
            **data["metrics"],
            "cv_mean": data["cv"]["cv_mean"],
            "cv_std":  data["cv"]["cv_std"],
            "fit_time": data["fit_time"],
            "pred_time": data["pred_time"],
        }

    metadata = {
        "training_timestamp": get_timestamp(),
        "best_model":         best_name,
        "best_r2":            results[best_name]["metrics"]["R2"],
        "best_mae":           results[best_name]["metrics"]["MAE"],
        "best_rmse":          results[best_name]["metrics"]["RMSE"],
        "best_mape":          results[best_name]["metrics"]["MAPE"],
        "dataset_rows":       int(len(training_output["y_train"]) + len(training_output["y_test"])),
        "dataset_cols":       len(feature_names) + 1,
        "n_features":         len(feature_names),
        "test_size":          config.TEST_SIZE,
        "random_state":       config.RANDOM_STATE,
        "cv_folds":           config.CV_FOLDS,
        "cv_score":           results[best_name]["cv"]["cv_mean"],
        "polynomial_degree":  config.POLYNOMIAL_DEGREE,
        "app_version":        config.APP_VERSION,
        "model_version":      config.MODEL_VERSION,
        "model_metrics":      metrics_summary,
    }
    save_json(metadata, models_dir / "metadata.json")
    logger.info("Saved: metadata.json")

    logger.info("All artifacts saved to %s", models_dir)
