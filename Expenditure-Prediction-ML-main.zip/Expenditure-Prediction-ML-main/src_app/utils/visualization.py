"""
visualization.py
────────────────
Plotly chart builders for the Streamlit dashboard.
Every function returns a ``plotly.graph_objects.Figure`` ready
to be rendered with ``st.plotly_chart(fig, use_container_width=True)``.
"""

import logging
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# ── Ensure src_app is on sys.path ──
_SRC_APP = str(Path(__file__).resolve().parent.parent)
if _SRC_APP not in sys.path:
    sys.path.insert(0, _SRC_APP)

import config  # noqa: E402

logger = logging.getLogger(__name__)

# ── Shared Plotly template ──
_TEMPLATE = "plotly_dark"
_FONT = dict(family="Inter, sans-serif", size=13)
_MARGIN = dict(l=40, r=40, t=50, b=40)


def _base_layout() -> Dict[str, Any]:
    """Common layout settings applied to every chart."""
    return dict(
        template=_TEMPLATE,
        font=_FONT,
        margin=_MARGIN,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
    )


# ═══════════════════════════════════════════════════
#  EXPLORATORY DATA ANALYSIS
# ═══════════════════════════════════════════════════

def plot_correlation_heatmap(df: pd.DataFrame) -> go.Figure:
    """Interactive correlation heatmap."""
    corr = df.corr(numeric_only=True)
    fig = go.Figure(
        data=go.Heatmap(
            z=corr.values,
            x=corr.columns,
            y=corr.columns,
            colorscale="RdBu_r",
            zmin=-1,
            zmax=1,
            text=np.round(corr.values, 2),
            texttemplate="%{text}",
            textfont=dict(size=10),
            hovertemplate="<b>%{x}</b> vs <b>%{y}</b><br>Correlation: %{z:.3f}<extra></extra>",
        )
    )
    fig.update_layout(
        title="Feature Correlation Heatmap",
        height=650,
        **_base_layout(),
    )
    return fig


def plot_distribution(
    df: pd.DataFrame,
    column: str,
    nbins: int = 40,
) -> go.Figure:
    """Histogram with KDE overlay for a single column."""
    fig = px.histogram(
        df,
        x=column,
        nbins=nbins,
        marginal="box",
        color_discrete_sequence=[config.COLORS["primary"]],
        title=f"Distribution of {column}",
    )
    fig.update_layout(
        height=450,
        **_base_layout(),
    )
    return fig


def plot_boxplot(df: pd.DataFrame, columns: Optional[List[str]] = None) -> go.Figure:
    """Box plots for selected (or all numeric) columns."""
    if columns is None:
        columns = df.select_dtypes(include=[np.number]).columns.tolist()

    fig = go.Figure()
    colors = px.colors.qualitative.Vivid
    for i, col in enumerate(columns):
        fig.add_trace(go.Box(
            y=df[col],
            name=col,
            marker_color=colors[i % len(colors)],
            boxmean="sd",
        ))

    fig.update_layout(
        title="Feature Box Plots",
        showlegend=False,
        xaxis_tickangle=-45,
        height=500,
        **_base_layout(),
    )
    return fig


def plot_scatter(
    df: pd.DataFrame,
    x_col: str,
    y_col: str,
    trendline: bool = True,
) -> go.Figure:
    """Scatter plot with optional OLS trendline."""
    fig = px.scatter(
        df,
        x=x_col,
        y=y_col,
        trendline="ols" if trendline else None,
        color_discrete_sequence=[config.COLORS["accent"]],
        title=f"{y_col} vs {x_col}",
    )
    fig.update_layout(height=450, **_base_layout())
    return fig


def plot_pairplot(
    df: pd.DataFrame,
    columns: List[str],
) -> go.Figure:
    """Scatter matrix (pair plot) for selected columns."""
    fig = px.scatter_matrix(
        df[columns],
        dimensions=columns,
        color_discrete_sequence=[config.COLORS["primary"]],
        title="Pair Plot",
    )
    fig.update_traces(diagonal_visible=False, marker=dict(size=3, opacity=0.5))
    fig.update_layout(height=700, **_base_layout())
    return fig


# ═══════════════════════════════════════════════════
#  MODEL EVALUATION
# ═══════════════════════════════════════════════════

def plot_model_comparison(
    metrics: Dict[str, Dict[str, float]],
    metric_name: str = "R2",
    title: Optional[str] = None,
) -> go.Figure:
    """Horizontal bar chart comparing models on a chosen metric."""
    names = list(metrics.keys())
    values = [metrics[n][metric_name] for n in names]

    # Sort by value
    sorted_pairs = sorted(zip(names, values), key=lambda x: x[1])
    names, values = zip(*sorted_pairs)

    best_idx = np.argmax(values)
    colors = [
        config.COLORS["success"] if i == best_idx else config.COLORS["primary"]
        for i in range(len(values))
    ]

    fig = go.Figure(go.Bar(
        x=list(values),
        y=list(names),
        orientation="h",
        marker_color=colors,
        text=[f"{v:.4f}" for v in values],
        textposition="outside",
    ))
    fig.update_layout(
        title=title or f"Model Comparison — {metric_name}",
        xaxis_title=metric_name,
        height=max(350, 50 * len(names)),
        **_base_layout(),
    )
    return fig


def plot_all_metrics_table(
    metrics: Dict[str, Dict[str, float]],
) -> go.Figure:
    """Plotly table summarising all metrics for every model."""
    model_names = list(metrics.keys())
    metric_keys = ["R2", "MAE", "RMSE", "MAPE", "cv_mean"]
    display_names = ["R²", "MAE", "RMSE", "MAPE (%)", "CV Mean R²"]

    header_values = ["Model"] + display_names
    cell_values = [model_names]
    for key in metric_keys:
        cell_values.append([
            f"{metrics[m].get(key, 0):.4f}" for m in model_names
        ])

    # Highlight best model row
    best_name = max(metrics, key=lambda n: metrics[n].get("R2", 0))
    fill_colors = []
    for m in model_names:
        if m == best_name:
            fill_colors.append("rgba(16,185,129,0.25)")  # emerald tint
        else:
            fill_colors.append("rgba(255,255,255,0.05)")

    fig = go.Figure(data=[go.Table(
        header=dict(
            values=header_values,
            fill_color=config.COLORS["surface"],
            font=dict(color="white", size=13),
            align="center",
        ),
        cells=dict(
            values=cell_values,
            fill_color=[fill_colors] * len(header_values),
            font=dict(color="white", size=12),
            align="center",
            height=30,
        ),
    )])
    fig.update_layout(
        title="Model Performance Summary",
        height=max(300, 45 * len(model_names) + 80),
        margin=dict(l=0, r=0, t=40, b=0),
        paper_bgcolor="rgba(0,0,0,0)",
    )
    return fig


def plot_actual_vs_predicted(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    model_name: str = "Model",
) -> go.Figure:
    """Scatter of actual vs predicted with a 45° reference line."""
    fig = go.Figure()

    fig.add_trace(go.Scatter(
        x=y_true,
        y=y_pred,
        mode="markers",
        marker=dict(color=config.COLORS["primary"], size=6, opacity=0.6),
        name="Predictions",
        hovertemplate="Actual: %{x:.2f}<br>Predicted: %{y:.2f}<extra></extra>",
    ))

    # Perfect-prediction line
    min_val = min(np.min(y_true), np.min(y_pred))
    max_val = max(np.max(y_true), np.max(y_pred))
    fig.add_trace(go.Scatter(
        x=[min_val, max_val],
        y=[min_val, max_val],
        mode="lines",
        line=dict(color=config.COLORS["danger"], dash="dash", width=2),
        name="Perfect Prediction",
    ))

    fig.update_layout(
        title=f"Actual vs Predicted — {model_name}",
        xaxis_title="Actual Expenditure (₹ Lakhs)",
        yaxis_title="Predicted Expenditure (₹ Lakhs)",
        height=500,
        **_base_layout(),
    )
    return fig


def plot_residuals(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    model_name: str = "Model",
) -> go.Figure:
    """Residual scatter plot (predicted vs residuals)."""
    residuals = np.asarray(y_true) - np.asarray(y_pred)

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=y_pred,
        y=residuals,
        mode="markers",
        marker=dict(color=config.COLORS["accent"], size=5, opacity=0.6),
        name="Residuals",
        hovertemplate="Predicted: %{x:.2f}<br>Residual: %{y:.2f}<extra></extra>",
    ))
    fig.add_hline(y=0, line_dash="dash", line_color=config.COLORS["danger"])

    fig.update_layout(
        title=f"Residual Plot — {model_name}",
        xaxis_title="Predicted Values",
        yaxis_title="Residuals",
        height=450,
        **_base_layout(),
    )
    return fig


# ═══════════════════════════════════════════════════
#  FEATURE IMPORTANCE
# ═══════════════════════════════════════════════════

def plot_feature_importance(
    importances: np.ndarray,
    feature_names: List[str],
    model_name: str = "Model",
    top_n: Optional[int] = None,
) -> go.Figure:
    """Horizontal bar chart of feature importances."""
    idx = np.argsort(importances)
    if top_n:
        idx = idx[-top_n:]

    sorted_names = [feature_names[i] for i in idx]
    sorted_vals = importances[idx]

    fig = go.Figure(go.Bar(
        x=sorted_vals,
        y=sorted_names,
        orientation="h",
        marker=dict(
            color=sorted_vals,
            colorscale="Viridis",
            showscale=True,
            colorbar=dict(title="Importance"),
        ),
        text=[f"{v:.4f}" for v in sorted_vals],
        textposition="outside",
    ))
    fig.update_layout(
        title=f"Feature Importance — {model_name}",
        xaxis_title="Importance Score",
        height=max(350, 40 * len(sorted_names)),
        **_base_layout(),
    )
    return fig


# ═══════════════════════════════════════════════════
#  SCALING COMPARISON
# ═══════════════════════════════════════════════════

def plot_scaling_comparison(
    before: np.ndarray,
    after: np.ndarray,
    feature_name: str = "Feature",
) -> go.Figure:
    """Side-by-side histograms showing before/after MinMaxScaling."""
    fig = make_subplots(rows=1, cols=2, subplot_titles=("Before Scaling", "After Scaling"))

    fig.add_trace(
        go.Histogram(x=before, marker_color=config.COLORS["warning"], name="Raw"),
        row=1, col=1,
    )
    fig.add_trace(
        go.Histogram(x=after, marker_color=config.COLORS["success"], name="Scaled"),
        row=1, col=2,
    )
    fig.update_layout(
        title=f"Scaling Comparison — {feature_name}",
        showlegend=False,
        height=400,
        **_base_layout(),
    )
    return fig
