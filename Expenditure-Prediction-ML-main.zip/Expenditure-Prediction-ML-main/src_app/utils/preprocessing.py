"""
preprocessing.py
────────────────
Data loading, missing-value imputation, IQR-based outlier removal,
and MinMaxScaler feature scaling — extracted from the original
``project file.py`` to be reusable across training and inference.
"""

import logging
import sys
from pathlib import Path
from typing import Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler

# ── Ensure src_app is on sys.path ──
_SRC_APP = str(Path(__file__).resolve().parent.parent)
if _SRC_APP not in sys.path:
    sys.path.insert(0, _SRC_APP)

import config  # noqa: E402

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════
#  DATA LOADING
# ═══════════════════════════════════════════════════

def load_data(csv_path: Optional[str] = None) -> pd.DataFrame:
    """Load the raw CSV dataset.

    Args:
        csv_path: Path to the CSV file.  Falls back to
                  ``config.DATASET_PATH`` when *None*.

    Returns:
        Raw ``DataFrame`` with all original columns.

    Raises:
        FileNotFoundError: If the CSV does not exist.
    """
    csv_path = Path(csv_path) if csv_path else config.DATASET_PATH
    if not csv_path.exists():
        raise FileNotFoundError(f"Dataset not found: {csv_path}")
    df = pd.read_csv(csv_path)
    logger.info("Loaded dataset: %d rows × %d cols from %s", *df.shape, csv_path.name)
    return df


def select_numeric_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Keep only the numeric columns defined in ``config.ALL_COLUMNS``.

    Args:
        df: Raw dataframe (may contain text columns like STATE_NAME).

    Returns:
        DataFrame with only the configured numeric + target columns.
    """
    cols = [c for c in config.ALL_COLUMNS if c in df.columns]
    return df[cols].copy()


# ═══════════════════════════════════════════════════
#  MISSING VALUES
# ═══════════════════════════════════════════════════

def handle_missing_values(df: pd.DataFrame) -> pd.DataFrame:
    """Fill missing values with the column median (matches ``project file.py``).

    Args:
        df: DataFrame with potential NaN values.

    Returns:
        DataFrame with NaN values replaced by column medians.
    """
    missing_before = int(df.isnull().sum().sum())
    df = df.copy()
    df.fillna(df.median(numeric_only=True), inplace=True)
    logger.info("Missing values filled: %d → 0", missing_before)
    return df


# ═══════════════════════════════════════════════════
#  OUTLIER REMOVAL
# ═══════════════════════════════════════════════════

def remove_outliers_iqr(df: pd.DataFrame) -> pd.DataFrame:
    """Remove rows outside the 1.5×IQR fence for every column.

    This replicates the exact logic from ``project file.py``.

    Args:
        df: Cleaned DataFrame (no NaN values expected).

    Returns:
        Filtered DataFrame.
    """
    rows_before = len(df)
    for col in df.columns:
        q1 = df[col].quantile(0.25)
        q3 = df[col].quantile(0.75)
        iqr = q3 - q1
        lower = q1 - 1.5 * iqr
        upper = q3 + 1.5 * iqr
        df = df[(df[col] >= lower) & (df[col] <= upper)]
    rows_removed = rows_before - len(df)
    logger.info("Outlier removal: %d → %d rows  (removed %d)", rows_before, len(df), rows_removed)
    return df


# ═══════════════════════════════════════════════════
#  FEATURE / TARGET SPLIT
# ═══════════════════════════════════════════════════

def get_features_and_target(
    df: pd.DataFrame,
    target: str = config.TARGET_COLUMN,
) -> Tuple[pd.DataFrame, pd.Series]:
    """Split the DataFrame into feature matrix ``X`` and target vector ``y``.

    Args:
        df:     Cleaned DataFrame containing both features and target.
        target: Name of the target column.

    Returns:
        Tuple of ``(X, y)``.
    """
    X = df.drop(columns=[target])
    y = df[target]
    logger.info("Features: %d  |  Target: %s", X.shape[1], target)
    return X, y


# ═══════════════════════════════════════════════════
#  SCALING
# ═══════════════════════════════════════════════════

def scale_features(
    X: pd.DataFrame,
    scaler: Optional[MinMaxScaler] = None,
) -> Tuple[np.ndarray, MinMaxScaler]:
    """Apply MinMaxScaler to the feature matrix.

    If a fitted *scaler* is supplied (inference mode), it is used to
    transform ``X`` without re-fitting.  Otherwise a new scaler is
    fitted on ``X`` (training mode).

    Args:
        X:      Feature DataFrame or array.
        scaler: Pre-fitted scaler (optional, for inference).

    Returns:
        Tuple of ``(X_scaled, scaler)``.
    """
    if scaler is None:
        scaler = MinMaxScaler()
        X_scaled = scaler.fit_transform(X)
        logger.info("Fitted new MinMaxScaler on %d features", X.shape[1] if hasattr(X, "shape") else len(X))
    else:
        X_scaled = scaler.transform(X)
        logger.info("Transformed features with pre-fitted scaler")
    return X_scaled, scaler


# ═══════════════════════════════════════════════════
#  FULL PIPELINE (convenience)
# ═══════════════════════════════════════════════════

def preprocess_pipeline(
    csv_path: Optional[str] = None,
) -> Tuple[np.ndarray, pd.Series, MinMaxScaler, pd.DataFrame, pd.DataFrame]:
    """Run the complete preprocessing pipeline used during training.

    Steps (matching ``project file.py``):
        1. Load CSV
        2. Select numeric columns
        3. Fill missing values with median
        4. Remove IQR outliers
        5. Split X / y
        6. Scale X with MinMaxScaler

    Args:
        csv_path: Path to the CSV (defaults to ``config.DATASET_PATH``).

    Returns:
        Tuple of ``(X_scaled, y, scaler, df_clean, df_raw)``.
            - ``X_scaled``:  Scaled feature numpy array.
            - ``y``:         Target Series.
            - ``scaler``:    Fitted MinMaxScaler instance.
            - ``df_clean``:  Cleaned DataFrame (after outlier removal).
            - ``df_raw``:    Raw DataFrame (after column selection, before cleaning).
    """
    df_full = load_data(csv_path)
    df_numeric = select_numeric_columns(df_full)
    df_raw = df_numeric.copy()

    df_clean = handle_missing_values(df_numeric)
    df_clean = remove_outliers_iqr(df_clean)

    X, y = get_features_and_target(df_clean)
    X_scaled, scaler = scale_features(X)

    return X_scaled, y, scaler, df_clean, df_raw
