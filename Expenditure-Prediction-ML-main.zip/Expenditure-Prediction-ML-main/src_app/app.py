"""
app.py
------
Main Streamlit entry point for the Road Infrastructure
Expenditure Prediction System.

Usage
-----
    cd  <workspace root>          # the ``app.py/`` folder
    streamlit run src_app/app.py
"""

import sys
from pathlib import Path

import streamlit as st

# ── Ensure src_app is importable ──
_SRC_APP = str(Path(__file__).resolve().parent)
if _SRC_APP not in sys.path:
    sys.path.insert(0, _SRC_APP)

# ═══════════════════════════════════════════════════
#  PAGE CONFIG  (must be the first Streamlit call)
# ═══════════════════════════════════════════════════
st.set_page_config(
    page_title="Road Infrastructure Prediction System",
    page_icon="🛣️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Imports (after set_page_config) ──
import config  # noqa: E402
from utils.logger import get_logger  # noqa: E402
from utils.prediction import load_artifacts  # noqa: E402
from pages.Home import render as render_home  # noqa: E402
from pages.Prediction import render as render_prediction  # noqa: E402
from pages.Dataset_Analysis import render as render_dataset_analysis  # noqa: E402
from pages.Model_Comparison import render as render_model_comparison  # noqa: E402

logger = get_logger(__name__)
logger.info("Application startup: Initializing Streamlit UI.")


# ═══════════════════════════════════════════════════
#  CUSTOM CSS
# ═══════════════════════════════════════════════════
CUSTOM_CSS = """
<style>
/* ─── HIDE STREAMLIT DEFAULTS ─── */
[data-testid="stSidebarNav"]   { display: none !important; }
#MainMenu                      { visibility: hidden; }
footer                         { visibility: hidden; }

/* ─── GOOGLE FONT ─── */
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
*, html, body, [class*="st-"] {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI',
                 Roboto, sans-serif !important;
}

/* ─── APP BACKGROUND ─── */
.stApp {
    background: linear-gradient(160deg, #0F172A 0%, #1a1147 50%, #0F172A 100%);
}

/* ─── SIDEBAR ─── */
section[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #1E1B4B 0%, #0F172A 100%) !important;
    border-right: 1px solid rgba(99,102,241,0.15);
}
section[data-testid="stSidebar"] .block-container { padding-top: 0; }

/* ─── HERO ─── */
.hero-container {
    text-align: center;
    padding: 2.5rem 1rem 2rem;
}
.hero-badge {
    display: inline-block;
    background: rgba(99,102,241,0.15);
    border: 1px solid rgba(99,102,241,0.3);
    border-radius: 20px;
    padding: 0.4rem 1.1rem;
    font-size: 0.82rem;
    color: #A5B4FC;
    margin-bottom: 1rem;
    letter-spacing: 0.04em;
    font-weight: 500;
}
.hero-title {
    font-size: 2.6rem;
    font-weight: 800;
    background: linear-gradient(135deg, #6366F1 0%, #8B5CF6 40%, #EC4899 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: 0.8rem;
    line-height: 1.15;
}
.hero-subtitle {
    font-size: 1.1rem;
    color: #94A3B8;
    max-width: 620px;
    margin: 0 auto;
    line-height: 1.65;
}

/* ─── METRIC CARD ─── */
.metric-card {
    background: rgba(30, 41, 59, 0.55);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border: 1px solid rgba(99, 102, 241, 0.18);
    border-radius: 16px;
    padding: 1.4rem 1rem;
    text-align: center;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    margin-bottom: 0.6rem;
}
.metric-card:hover {
    transform: translateY(-4px);
    border-color: rgba(99,102,241,0.45);
    box-shadow: 0 12px 40px rgba(99,102,241,0.12);
}
.metric-icon  { font-size: 1.7rem; margin-bottom: 0.4rem; }
.metric-value {
    font-size: 1.8rem;
    font-weight: 800;
    background: linear-gradient(135deg, #6366F1, #EC4899);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    line-height: 1.2;
}
.metric-label {
    font-size: 0.78rem;
    color: #94A3B8;
    text-transform: uppercase;
    letter-spacing: 0.07em;
    margin-top: 0.45rem;
    font-weight: 500;
}

/* ─── GLASS CARD ─── */
.glass-card {
    background: rgba(30, 41, 59, 0.45);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border: 1px solid rgba(99, 102, 241, 0.14);
    border-radius: 16px;
    padding: 1.6rem;
    margin-bottom: 1rem;
}

/* ─── SECTION HEADER ─── */
.section-header {
    font-size: 1.35rem;
    font-weight: 700;
    color: #F1F5F9;
    margin: 2rem 0 1rem;
    padding-bottom: 0.55rem;
    border-bottom: 2px solid rgba(99,102,241,0.25);
}

/* ─── WORKFLOW STEP ─── */
.workflow-step {
    background: rgba(30, 41, 59, 0.4);
    border: 1px solid rgba(99, 102, 241, 0.14);
    border-radius: 12px;
    padding: 1rem 0.6rem;
    text-align: center;
    transition: all 0.2s ease;
    margin-bottom: 0.5rem;
}
.workflow-step:hover {
    border-color: rgba(99,102,241,0.4);
    background: rgba(30, 41, 59, 0.65);
}
.workflow-icon  { font-size: 1.4rem; margin-bottom: 0.3rem; }
.workflow-title { font-size: 0.82rem; font-weight: 600; color: #E2E8F0; }
.workflow-desc  { font-size: 0.7rem; color: #94A3B8; }

/* ─── TECH BADGE ─── */
.tech-badge {
    display: inline-block;
    background: rgba(99,102,241,0.12);
    border: 1px solid rgba(99,102,241,0.22);
    border-radius: 20px;
    padding: 0.35rem 0.9rem;
    margin: 0.25rem;
    font-size: 0.8rem;
    color: #A5B4FC;
    font-weight: 500;
}

/* ─── PREDICTION RESULT CARD ─── */
.prediction-result-card {
    background: rgba(30, 41, 59, 0.55);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border-radius: 20px;
    padding: 2.5rem 2rem;
    text-align: center;
    animation: fadeInUp 0.5s ease;
}
@keyframes fadeInUp {
    from { opacity: 0; transform: translateY(20px); }
    to   { opacity: 1; transform: translateY(0); }
}
.prediction-label {
    font-size: 0.88rem;
    color: #94A3B8;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    margin-bottom: 0.5rem;
    font-weight: 500;
}
.prediction-value {
    font-size: 2.8rem;
    font-weight: 800;
    line-height: 1.2;
    margin-bottom: 0.2rem;
}
.prediction-unit {
    font-size: 0.85rem;
    color: #64748B;
    margin-bottom: 1.2rem;
}
.category-badge {
    display: inline-block;
    padding: 0.5rem 1.5rem;
    border-radius: 25px;
    font-size: 0.88rem;
    font-weight: 600;
}

/* ─── FORM BUTTON ─── */
.stFormSubmitButton > button {
    background: linear-gradient(135deg, #6366F1, #8B5CF6) !important;
    color: white !important;
    border: none !important;
    border-radius: 12px !important;
    padding: 0.65rem 2rem !important;
    font-weight: 600 !important;
    font-size: 0.95rem !important;
    transition: all 0.3s ease !important;
}
.stFormSubmitButton > button:hover {
    box-shadow: 0 8px 25px rgba(99,102,241,0.35) !important;
    transform: translateY(-2px) !important;
}
.stFormSubmitButton > button:active {
    transform: translateY(0) !important;
}

/* ─── DIVIDER ─── */
hr { border-color: rgba(99,102,241,0.12) !important; }

/* ─── COMING SOON ─── */
.coming-soon {
    text-align: center;
    padding: 5rem 2rem;
}
.coming-soon-icon  { font-size: 4rem; margin-bottom: 1rem; }
.coming-soon-title { font-size: 1.6rem; font-weight: 600; color: #E2E8F0; }
.coming-soon-text  { font-size: 1rem; color: #64748B; margin-top: 0.6rem; }
</style>
"""

st.markdown(CUSTOM_CSS, unsafe_allow_html=True)


# ═══════════════════════════════════════════════════
#  LOAD MODEL ARTIFACTS  (cached across reruns)
# ═══════════════════════════════════════════════════
@st.cache_resource(show_spinner=False)
def _load_artifacts():
    """Load model artifacts once and cache across sessions."""
    return load_artifacts()


try:
    artifacts = _load_artifacts()
    logger.info("Model artifacts loaded successfully.")
except FileNotFoundError as exc:
    logger.error("Model artifacts not found: %s", exc)
    st.error(
        "🚨 Model artifacts not found!  "
        "Please run **`python3 src_app/train_models.py`** first "
        "to train the models and save the required files."
    )
    st.stop()
except Exception as exc:
    logger.exception("Failed to load model artifacts: %s", exc)
    st.error(f"🚨 Failed to load model artifacts: {exc}")
    st.stop()


# ═══════════════════════════════════════════════════
#  SIDEBAR
# ═══════════════════════════════════════════════════
with st.sidebar:
    # Branding
    st.markdown("""
    <div style="text-align:center; padding:1.2rem 0 0.6rem;">
        <div style="font-size:2.8rem; line-height:1;">🛣️</div>
        <div style="font-size:1.05rem; font-weight:700; color:#E2E8F0;
                    margin-top:0.4rem; letter-spacing:0.02em;">
            Road Infra Predictor
        </div>
        <div style="font-size:0.72rem; color:#94A3B8; margin-top:0.15rem;">
            Expenditure Prediction System
        </div>
    </div>
    """, unsafe_allow_html=True)

    st.divider()

    # Navigation
    page = st.radio(
        "Navigation",
        [
            "🏠  Home",
            "🔮  Prediction",
            "📊  Dataset Analysis",
            "📈  Model Comparison",
            "🎯  Feature Importance",
            "📋  Batch Prediction",
            "ℹ️  About",
            "🩺  System Health",
        ],
        label_visibility="collapsed",
    )

    st.divider()

    # Model info panel
    meta = artifacts["metadata"]
    with st.expander("🤖 Active Model", expanded=False):
        st.caption(f"**Model:** {meta['best_model']}")
        st.caption(f"**R² Score:** {meta['best_r2']:.4f}")
        st.caption(f"**Features:** {meta['n_features']}")
        st.caption(f"**Trained:** {meta['training_timestamp'][:10]}")

    st.divider()

    # Footer
    st.markdown(f"""
    <div style="text-align:center; padding:1rem 0; border-top:1px solid rgba(99,102,241,0.12); margin-top:2rem;">
        <div style="font-size:0.75rem; font-weight:600; color:#CBD5E1; margin-bottom:0.3rem;">
            Road Infrastructure Expenditure Prediction System
        </div>
        <div style="font-size:0.65rem; color:#64748B;">
            Developed using Python, Streamlit, Scikit-Learn, XGBoost & Plotly
        </div>
        <div style="font-size:0.65rem; color:#475569; margin-top:0.4rem;">
            Built by <strong style="color:#A5B4FC;">{config.AUTHOR_NAME}</strong> | {config.AUTHOR_ROLL}
        </div>
        <div style="font-size:0.6rem; color:#334155; margin-top:0.2rem;">
            v{config.APP_VERSION}
        </div>
    </div>
    """, unsafe_allow_html=True)


# ═══════════════════════════════════════════════════
#  HELPERS
# ═══════════════════════════════════════════════════
def _coming_soon(name: str) -> None:
    """Placeholder for pages not yet implemented."""
    st.markdown(f"""
    <div class="coming-soon">
        <div class="coming-soon-icon">🚧</div>
        <div class="coming-soon-title">{name}</div>
        <div class="coming-soon-text">
            This page is under construction and will be available soon.
        </div>
    </div>
    """, unsafe_allow_html=True)


# ═══════════════════════════════════════════════════
#  PAGE ROUTING
# ═══════════════════════════════════════════════════
if "Home" in page:
    render_home(artifacts)

elif "Prediction" in page:
    render_prediction(artifacts)

elif "Dataset Analysis" in page:
    render_dataset_analysis(artifacts)

elif "Model Comparison" in page:
    render_model_comparison(artifacts)

elif "Feature Importance" in page:
    from pages.Feature_Importance import render as render_feature_importance
    render_feature_importance(artifacts)

elif "Batch Prediction" in page:
    from pages.Batch_Prediction import render as render_batch_prediction
    render_batch_prediction(artifacts)

elif "About" in page:
    from pages.About import render as render_about
    render_about(artifacts)

elif "System Health" in page:
    from pages.System_Health import render as render_system_health
    render_system_health(artifacts)
