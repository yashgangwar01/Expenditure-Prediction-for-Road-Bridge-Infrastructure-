"""Quick verification that inference works end-to-end."""
import sys, io
from pathlib import Path

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

sys.path.insert(0, str(Path(__file__).resolve().parent))

from utils.prediction import load_artifacts, predict_single

artifacts = load_artifacts()

sample = {
    "NO_OF_ROAD_WORK_SANCTIONED": 50,
    "NO_OF_BRIDGES_SANCTIONED": 10,
    "NO_OF_ROAD_WORKS_COMPLETED": 40,
    "NO_OF_BRIDGES_COMPLETED": 8,
    "NO_OF_ROAD_WORKS_BALANCE": 10,
    "NO_OF_BRIDGES_BALANCE": 2,
    "LENGTH_OF_ROAD_WORK_SANCTIONED_KM": 100.0,
    "COST_OF_WORKS_SANCTIONED_LAKHS": 500.0,
    "LENGTH_OF_ROAD_WORK_COMPLETED_KM": 80.0,
    "LENGTH_OF_ROAD_WORK_BALANCE_KM": 20.0,
}

result = predict_single(sample, artifacts)

print("=" * 50)
print("  INFERENCE VERIFICATION")
print("=" * 50)
print(f"  Best Model : {artifacts['metadata']['best_model']}")
print(f"  Prediction : {result['prediction']:.2f} Lakhs")
print(f"  Category   : {result['icon']}  {result['category']}")
print(f"  Color      : {result['color']}")
print(f"  Features   : {len(artifacts['feature_names'])}")
print(f"  All Models : {list(artifacts['all_models'].keys())}")
print("=" * 50)
print("  Inference OK!")
print("=" * 50)
