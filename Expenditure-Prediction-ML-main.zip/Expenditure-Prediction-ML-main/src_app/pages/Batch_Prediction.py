"""
Batch_Prediction.py
-------------------
Allows users to upload a CSV file with multiple projects,
validate the data, run batch predictions, and download the results.
"""

import sys
from pathlib import Path
from typing import Any, Dict
import io

import pandas as pd
import streamlit as st

_SRC_APP = str(Path(__file__).resolve().parent.parent)
if _SRC_APP not in sys.path:
    sys.path.insert(0, _SRC_APP)

import config
from utils.helpers import format_currency

def render(artifacts: Dict[str, Any]) -> None:
    """Render the Batch Prediction page."""
    
    st.markdown("""
    <div style="margin-bottom:1.5rem;">
        <h2 style="margin:0; color:#F8FAFC;">
            📋 Batch Prediction
        </h2>
        <p style="color:#94A3B8; margin-top:0.3rem;">
            Upload a CSV file to predict expenditure for multiple projects at once.
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    best_model_name = artifacts["metadata"]["best_model"]
    best_model = artifacts["all_models"][best_model_name]
    scaler = artifacts["scaler"]
    feature_names = artifacts["feature_names"]
    
    st.markdown(f"""
    <div class="glass-card">
        <p style="color:#CBD5E1; margin:0;">
            <strong>Active Model:</strong> {best_model_name}
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    st.markdown('<div class="section-header">📁 Upload Dataset</div>', unsafe_allow_html=True)
    
    # Template download
    template_df = pd.DataFrame(columns=feature_names)
    template_csv = template_df.to_csv(index=False).encode('utf-8')
    st.download_button(
        label="📥 Download CSV Template",
        data=template_csv,
        file_name='batch_prediction_template.csv',
        mime='text/csv',
    )
    
    uploaded_file = st.file_uploader("Upload your CSV file", type=["csv"])
    
    if uploaded_file is not None:
        try:
            df = pd.read_csv(uploaded_file)
            
            if df.empty:
                st.error("Uploaded file is empty.")
                return
                
            st.markdown('<div class="section-header">🔍 Data Validation</div>', unsafe_allow_html=True)
            
            # Check for missing columns
            missing_cols = [col for col in feature_names if col not in df.columns]
            
            if missing_cols:
                st.error(f"Missing required columns: {', '.join(missing_cols)}")
                return
                
            st.success("✅ Data structure validated successfully!")
            
            # Select only required columns
            df_input = df[feature_names].copy()
            
            # Handle missing values
            if df_input.isnull().sum().sum() > 0:
                st.warning("Found missing values. Filling with median values from the dataset.")
                df_input = df_input.fillna(df_input.median())
                
            # Preview
            with st.expander("Preview Uploaded Data", expanded=False):
                st.dataframe(df_input.head(), use_container_width=True)
                
            # Prediction
            st.markdown('<div class="section-header">🔮 Run Predictions</div>', unsafe_allow_html=True)
            
            if st.button("🚀 Predict Expenditure for All Rows", type="primary"):
                with st.spinner("Running predictions..."):
                    try:
                        # Scale
                        X_scaled = scaler.transform(df_input)
                        
                        # Polynomial check
                        if best_model_name == "Polynomial Regression" and "polynomial" in artifacts:
                            X_scaled = artifacts["polynomial"].transform(X_scaled)
                            
                        # Predict
                        preds = best_model.predict(X_scaled)
                        
                        # Add predictions to original dataframe
                        df_results = df.copy()
                        df_results["PREDICTED_EXPENDITURE_LAKHS"] = preds
                        
                        # Categorize
                        def categorize(val):
                            for cat, (low, high) in config.EXPENDITURE_CATEGORIES.items():
                                if low <= val < high:
                                    return cat
                            return "High"
                            
                        df_results["EXPENDITURE_CATEGORY"] = df_results["PREDICTED_EXPENDITURE_LAKHS"].apply(categorize)
                        
                        st.success(f"✅ Successfully generated predictions for {len(preds)} rows!")
                        
                        # Advanced Summary Statistics
                        c1, c2, c3, c4 = st.columns(4)
                        c1.metric("Total Predictions", len(preds))
                        c2.metric("Average Expenditure", format_currency(preds.mean(), suffix=" L"))
                        c3.metric("Max Expenditure", format_currency(preds.max(), suffix=" L"))
                        c4.metric("Min Expenditure", format_currency(preds.min(), suffix=" L"))
                        
                        st.markdown("<br>", unsafe_allow_html=True)
                        cat_counts = df_results["EXPENDITURE_CATEGORY"].value_counts()
                        hc, mc, lc = st.columns(3)
                        hc.metric("🔴 High Predictions", cat_counts.get("High", 0))
                        mc.metric("⚠️ Medium Predictions", cat_counts.get("Medium", 0))
                        lc.metric("✅ Low Predictions", cat_counts.get("Low", 0))
                        
                        st.markdown("<br>", unsafe_allow_html=True)
                        
                        # Display Results
                        st.dataframe(df_results, use_container_width=True)
                        
                        # Download Results
                        csv_output = df_results.to_csv(index=False).encode('utf-8')
                        st.download_button(
                            label="📥 Download Batch Prediction Report (CSV)",
                            data=csv_output,
                            file_name='batch_prediction_report.csv',
                            mime='text/csv',
                            use_container_width=True
                        )
                        
                    except Exception as e:
                        import logging
                        logging.getLogger(__name__).exception("Error during batch prediction: %s", e)
                        st.error(f"Error during prediction: {e}")
                
        except Exception as e:
            import logging
            logging.getLogger(__name__).exception("Error reading batch CSV: %s", e)
            st.error(f"Error reading the CSV file: {e}")
