"""
Home.py
-------
Home / landing page for the dashboard.
Displays project overview, key metrics, problem statement,
ML workflow, and technology stack.
"""

import sys
from pathlib import Path
from typing import Any, Dict

import streamlit as st

_SRC_APP = str(Path(__file__).resolve().parent.parent)
if _SRC_APP not in sys.path:
    sys.path.insert(0, _SRC_APP)

import config


def _metric_card(icon: str, value: str, label: str) -> str:
    """Return HTML for a single metric card."""
    return f"""
    <div class="metric-card">
        <div class="metric-icon">{icon}</div>
        <div class="metric-value">{value}</div>
        <div class="metric-label">{label}</div>
    </div>
    """


def _workflow_step(icon: str, title: str, desc: str) -> str:
    """Return HTML for a single workflow step."""
    return f"""
    <div class="workflow-step">
        <div class="workflow-icon">{icon}</div>
        <div class="workflow-title">{title}</div>
        <div class="workflow-desc">{desc}</div>
    </div>
    """


def render(artifacts: Dict[str, Any]) -> None:
    """Render the Home page."""
    metadata = artifacts["metadata"]
    best_model = metadata["best_model"]
    best_r2 = metadata["best_r2"]
    n_models = len(metadata["model_metrics"])

    # ── Hero Section ──
    st.markdown("""
    <div class="hero-container">
        <div class="hero-badge">🤖 Machine Learning Powered</div>
        <div class="hero-title">Road Infrastructure<br>Expenditure Prediction</div>
        <div class="hero-subtitle">
            Leveraging advanced regression models to predict road construction
            expenditure under the PMGSY scheme across Indian districts
        </div>
    </div>
    """, unsafe_allow_html=True)

    # ── Key Metrics Row 1 ──
    c1, c2, c3, c4 = st.columns(4)
    with c1:
        st.markdown(_metric_card("📊", f"{metadata['dataset_rows']:,}", "Dataset Size"), unsafe_allow_html=True)
    with c2:
        st.markdown(_metric_card("🔢", str(metadata["n_features"]), "Features"), unsafe_allow_html=True)
    with c3:
        st.markdown(_metric_card("🤖", str(n_models), "ML Models"), unsafe_allow_html=True)
    with c4:
        short_model = best_model.split()[0] if best_model else "N/A"
        st.markdown(_metric_card("🏆", short_model, "Best Model"), unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # ── Key Metrics Row 2 ──
    # Calculate session metrics
    history = st.session_state.get("prediction_history", [])
    pred_count = len(history)
    avg_pred = sum(item["prediction"] for item in history) / pred_count if pred_count > 0 else 0

    c5, c6, c7 = st.columns(3)
    with c5:
        st.markdown(_metric_card("⭐", f"{best_r2:.4f}", "Best R² Score"), unsafe_allow_html=True)
    with c6:
        st.markdown(_metric_card("📈", f"₹ {avg_pred:,.2f} L", "Avg Prediction"), unsafe_allow_html=True)
    with c7:
        st.markdown(_metric_card("🎯", str(pred_count), "Prediction Count"), unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # ── Problem Statement ──
    st.markdown(
        '<div class="section-header">📋 Problem Statement</div>',
        unsafe_allow_html=True,
    )
    st.markdown(f"""
    <div class="glass-card">
        <p style="color:#CBD5E1; line-height:1.8; margin:0 0 1rem;">
            The Government of India allocates significant budgets for rural road
            infrastructure through the <strong style="color:#A5B4FC;">PMGSY
            (Pradhan Mantri Gram Sadak Yojana)</strong> scheme.  Predicting the
            expenditure for road and bridge construction projects is critical for
            efficient budget planning and resource allocation.
        </p>
        <p style="color:#CBD5E1; line-height:1.8; margin:0;">
            This system builds a machine-learning pipeline that predicts
            <strong style="color:#6366F1;">EXPENDITURE_OCCURED_LAKHS</strong>
            based on project parameters — number of road works and bridges
            sanctioned, lengths completed, and sanctioned costs.  The best
            performing model is
            <strong style="color:#10B981;">{best_model}</strong> with an
            R² of <strong style="color:#10B981;">{best_r2:.4f}</strong>.
        </p>
    </div>
    """, unsafe_allow_html=True)

    # ── Target Variable ──
    st.markdown(
        '<div class="section-header">🎯 Target Variable</div>',
        unsafe_allow_html=True,
    )
    tc1, tc2 = st.columns([1, 2])
    with tc1:
        st.markdown("""
        <div class="metric-card" style="border-color:rgba(16,185,129,0.4);">
            <div class="metric-icon">💰</div>
            <div class="metric-value" style="font-size:1.3rem;
                 background:linear-gradient(135deg,#10B981,#6366F1);
                 -webkit-background-clip:text;-webkit-text-fill-color:transparent;
                 background-clip:text;">
                EXPENDITURE<br>OCCURED LAKHS
            </div>
            <div class="metric-label">Continuous · ₹ Lakhs</div>
        </div>
        """, unsafe_allow_html=True)
    with tc2:
        st.markdown("""
        <div class="glass-card" style="height:100%;">
            <p style="color:#CBD5E1; line-height:1.8; margin:0;">
                The target variable represents the <em>actual expenditure incurred</em>
                (in ₹ Lakhs) on road and bridge construction projects.  It is a
                continuous numeric value predicted using 10 independent features
                covering sanctioned quantities, completed quantities, and
                remaining balances.
            </p>
        </div>
        """, unsafe_allow_html=True)

    # ── Features ──
    st.markdown(
        '<div class="section-header">🔢 Input Features</div>',
        unsafe_allow_html=True,
    )
    feat_cols = st.columns(2)
    for i, feat in enumerate(config.NUMERIC_FEATURES):
        desc = config.FEATURE_DESCRIPTIONS.get(feat, feat)
        col = feat_cols[i % 2]
        with col:
            st.markdown(f"""
            <div style="display:flex; align-items:center; gap:0.6rem;
                        padding:0.55rem 0.8rem; margin-bottom:0.4rem;
                        background:rgba(30,41,59,0.4);
                        border:1px solid rgba(99,102,241,0.12);
                        border-radius:10px;">
                <span style="color:#6366F1; font-weight:700; font-size:0.75rem;
                             min-width:18px; text-align:center;">{i+1}</span>
                <div>
                    <div style="font-size:0.78rem; font-weight:600; color:#E2E8F0;">
                        {feat}
                    </div>
                    <div style="font-size:0.68rem; color:#94A3B8;">{desc}</div>
                </div>
            </div>
            """, unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # ── ML Workflow ──
    st.markdown(
        '<div class="section-header">⚙️ Machine Learning Workflow</div>',
        unsafe_allow_html=True,
    )
    wf = st.columns(6)
    steps = [
        ("📥", "Load Data", "2,296 rows"),
        ("🧹", "Clean Data", "Handle NaN"),
        ("✂️", "Remove Outliers", "IQR Method"),
        ("📏", "Scale Features", "MinMaxScaler"),
        ("🤖", "Train Models", f"{n_models} Models"),
        ("✅", "Evaluate", f"R²={best_r2:.2f}"),
    ]
    for col, (icon, title, desc) in zip(wf, steps):
        with col:
            st.markdown(_workflow_step(icon, title, desc), unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # ── Best Model Highlight ──
    st.markdown(
        '<div class="section-header">🏆 Best Performing Model</div>',
        unsafe_allow_html=True,
    )
    metrics = metadata["model_metrics"][best_model]
    bm1, bm2, bm3, bm4, bm5 = st.columns(5)
    with bm1:
        st.markdown(
            _metric_card("🏅", best_model.split()[0], "Model"),
            unsafe_allow_html=True,
        )
    with bm2:
        st.markdown(
            _metric_card("📈", f"{metrics['R2']:.4f}", "R² Score"),
            unsafe_allow_html=True,
        )
    with bm3:
        st.markdown(
            _metric_card("📉", f"{metrics['MAE']:.2f}", "MAE"),
            unsafe_allow_html=True,
        )
    with bm4:
        st.markdown(
            _metric_card("📊", f"{metrics['RMSE']:.2f}", "RMSE"),
            unsafe_allow_html=True,
        )
    with bm5:
        st.markdown(
            _metric_card("🔄", f"{metrics['cv_mean']:.4f}", "CV R² Mean"),
            unsafe_allow_html=True,
        )

    st.markdown("<br>", unsafe_allow_html=True)

    # ── Technology Stack ──
    st.markdown(
        '<div class="section-header">🛠️ Technology Stack</div>',
        unsafe_allow_html=True,
    )
    techs = [
        "Python 3", "Streamlit", "Scikit-learn", "Pandas", "NumPy",
        "Plotly", "XGBoost", "Joblib", "Matplotlib", "Seaborn",
    ]
    badges_html = " ".join(
        f'<span class="tech-badge">{t}</span>' for t in techs
    )
    st.markdown(
        f'<div class="glass-card" style="text-align:center;">{badges_html}</div>',
        unsafe_allow_html=True,
    )
