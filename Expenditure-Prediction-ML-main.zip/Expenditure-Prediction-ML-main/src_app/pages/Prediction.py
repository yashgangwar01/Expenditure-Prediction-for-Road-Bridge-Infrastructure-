"""
Prediction.py
─────────────
Single-sample prediction page.  Provides a form with all 10 input
features, validates input, runs inference via the saved model /
scaler, and displays the result in a professional metric card.
"""

import sys
from pathlib import Path
from typing import Any, Dict

import streamlit as st

_SRC_APP = str(Path(__file__).resolve().parent.parent)
if _SRC_APP not in sys.path:
    sys.path.insert(0, _SRC_APP)

import config
from utils.prediction import predict_single
from utils.helpers import format_currency


# ─── Feature input definitions ───
# Each tuple: (feature_name, label, help_text, min_val, max_val, default, step, is_float)
_FEATURE_INPUTS = [
    (
        "NO_OF_ROAD_WORK_SANCTIONED",
        "🛤️ Road Works Sanctioned",
        "Total number of road construction works sanctioned",
        0, 2000, 50, 1, False,
    ),
    (
        "NO_OF_BRIDGES_SANCTIONED",
        "🌉 Bridges Sanctioned",
        "Total number of bridge construction works sanctioned",
        0, 500, 10, 1, False,
    ),
    (
        "NO_OF_ROAD_WORKS_COMPLETED",
        "✅ Road Works Completed",
        "Number of road works that have been completed",
        0, 2000, 40, 1, False,
    ),
    (
        "NO_OF_BRIDGES_COMPLETED",
        "✅ Bridges Completed",
        "Number of bridge works that have been completed",
        0, 500, 8, 1, False,
    ),
    (
        "NO_OF_ROAD_WORKS_BALANCE",
        "⏳ Road Works Balance",
        "Number of road works still pending / in progress",
        0, 1000, 10, 1, False,
    ),
    (
        "NO_OF_BRIDGES_BALANCE",
        "⏳ Bridges Balance",
        "Number of bridge works still pending / in progress",
        0, 500, 2, 1, False,
    ),
    (
        "LENGTH_OF_ROAD_WORK_SANCTIONED_KM",
        "📏 Road Length Sanctioned (km)",
        "Total length of road work sanctioned in kilometres",
        0.0, 5000.0, 100.0, 0.1, True,
    ),
    (
        "COST_OF_WORKS_SANCTIONED_LAKHS",
        "💰 Cost Sanctioned (₹ Lakhs)",
        "Total cost of sanctioned works in Lakhs of Rupees",
        0.0, 100000.0, 500.0, 0.1, True,
    ),
    (
        "LENGTH_OF_ROAD_WORK_COMPLETED_KM",
        "✔️ Road Length Completed (km)",
        "Length of road work completed so far in kilometres",
        0.0, 5000.0, 80.0, 0.1, True,
    ),
    (
        "LENGTH_OF_ROAD_WORK_BALANCE_KM",
        "📐 Road Length Balance (km)",
        "Length of road work remaining in kilometres",
        0.0, 5000.0, 20.0, 0.1, True,
    ),
]


def _render_result_card(result: Dict[str, Any]) -> None:
    """Render the prediction result as a styled card."""
    prediction = result["prediction"]
    category = result["category"]
    icon = result["icon"]
    color = result["color"]

    st.markdown(f"""
    <div class="prediction-result-card" style="border:2px solid {color}40;">
        <div class="prediction-label">Predicted Expenditure</div>
        <div class="prediction-value" style="color:{color};">
            ₹ {prediction:,.2f}
        </div>
        <div class="prediction-unit">Lakhs (INR)</div>
        <div style="margin-top:0.5rem;">
            <span class="category-badge"
                  style="background:{color}18; color:{color};
                         border:1px solid {color}40;">
                {icon} {category} Expenditure
            </span>
        </div>
    </div>
    """, unsafe_allow_html=True)


def _render_waiting_card() -> None:
    """Render a placeholder card before prediction."""
    st.markdown("""
    <div class="prediction-result-card"
         style="border:1px dashed rgba(99,102,241,0.3);">
        <div style="font-size:3rem; margin-bottom:0.5rem;">🔮</div>
        <div style="color:#94A3B8; font-size:1rem; font-weight:500;">
            Fill in the project parameters and click
            <strong style="color:#A5B4FC;">Predict</strong>
            to see the estimated expenditure.
        </div>
    </div>
    """, unsafe_allow_html=True)


def _validate_inputs(values: Dict[str, float]) -> list:
    """Return a list of warning messages for unusual inputs."""
    warnings = []
    completed_roads = values.get("NO_OF_ROAD_WORKS_COMPLETED", 0)
    sanctioned_roads = values.get("NO_OF_ROAD_WORK_SANCTIONED", 0)
    if completed_roads > sanctioned_roads and sanctioned_roads > 0:
        warnings.append(
            "⚠️ Completed road works exceed sanctioned road works."
        )

    completed_bridges = values.get("NO_OF_BRIDGES_COMPLETED", 0)
    sanctioned_bridges = values.get("NO_OF_BRIDGES_SANCTIONED", 0)
    if completed_bridges > sanctioned_bridges and sanctioned_bridges > 0:
        warnings.append(
            "⚠️ Completed bridges exceed sanctioned bridges."
        )

    len_completed = values.get("LENGTH_OF_ROAD_WORK_COMPLETED_KM", 0)
    len_sanctioned = values.get("LENGTH_OF_ROAD_WORK_SANCTIONED_KM", 0)
    if len_completed > len_sanctioned and len_sanctioned > 0:
        warnings.append(
            "⚠️ Completed road length exceeds sanctioned length."
        )

    # Check if all values are zero
    if all(v == 0 for v in values.values()):
        warnings.append(
            "⚠️ All inputs are zero. Please enter at least one non-zero value."
        )

    return warnings


def render(artifacts: Dict[str, Any]) -> None:
    """Render the Prediction page."""

    # ── Header ──
    st.markdown("""
    <div style="margin-bottom:1.5rem;">
        <h2 style="margin:0; color:#F8FAFC;">
            🔮 Expenditure Prediction
        </h2>
        <p style="color:#94A3B8; margin-top:0.3rem;">
            Enter project parameters to predict the expected expenditure in ₹ Lakhs
        </p>
    </div>
    """, unsafe_allow_html=True)

    # ── Layout: form on left, result on right ──
    col_form, col_gap, col_result = st.columns([5, 0.5, 4])

    with col_form:
        st.markdown("""
        <div style="font-size:0.95rem; font-weight:600; color:#E2E8F0;
                    margin-bottom:0.8rem;">
            📝 Project Parameters
        </div>
        """, unsafe_allow_html=True)

        with st.form("prediction_form", clear_on_submit=False):
            input_values: Dict[str, float] = {}

            # Render inputs in two columns
            left, right = st.columns(2)

            for idx, (
                feat_name, label, help_text,
                min_v, max_v, default, step, is_float,
            ) in enumerate(_FEATURE_INPUTS):
                col = left if idx < 5 else right
                with col:
                    if is_float:
                        val = st.number_input(
                            label,
                            min_value=float(min_v),
                            max_value=float(max_v),
                            value=float(default),
                            step=float(step),
                            help=help_text,
                            key=f"input_{feat_name}",
                        )
                    else:
                        val = st.number_input(
                            label,
                            min_value=int(min_v),
                            max_value=int(max_v),
                            value=int(default),
                            step=int(step),
                            help=help_text,
                            key=f"input_{feat_name}",
                        )
                    input_values[feat_name] = float(val)

            st.markdown("<br>", unsafe_allow_html=True)
            submitted = st.form_submit_button(
                "🔮  Predict Expenditure",
                use_container_width=True,
                type="primary",
            )

    # ── Result Column ──
    with col_result:
        st.markdown("""
        <div style="font-size:0.95rem; font-weight:600; color:#E2E8F0;
                    margin-bottom:0.8rem;">
            📊 Prediction Result
        </div>
        """, unsafe_allow_html=True)

        if submitted:
            # Validate
            warnings = _validate_inputs(input_values)
            for w in warnings:
                st.warning(w)

            # Predict
            try:
                with st.spinner("Running prediction..."):
                    result = predict_single(input_values, artifacts)

                _render_result_card(result)

                # Additional details in an expander
                with st.expander("📋 Input Summary", expanded=False):
                    for feat_name, val in input_values.items():
                        desc = config.FEATURE_DESCRIPTIONS.get(feat_name, feat_name)
                        if val == int(val):
                            st.markdown(
                                f"**{desc}:** {int(val)}"
                            )
                        else:
                            st.markdown(
                                f"**{desc}:** {val:,.2f}"
                            )

                # Model info
                st.markdown(f"""
                <div style="text-align:center; margin-top:1rem;
                            padding:0.8rem; border-radius:10px;
                            background:rgba(30,41,59,0.4);
                            border:1px solid rgba(99,102,241,0.12);">
                    <span style="color:#94A3B8; font-size:0.78rem;">
                        Model: <strong style="color:#A5B4FC;">
                        {artifacts['metadata']['best_model']}</strong>
                        &nbsp;·&nbsp;
                        R²: <strong style="color:#10B981;">
                        {artifacts['metadata']['best_r2']:.4f}</strong>
                    </span>
                </div>
                """, unsafe_allow_html=True)
                
                # Add to history
                if "prediction_history" not in st.session_state:
                    st.session_state.prediction_history = []
                import datetime
                history_entry = {
                    "Timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    **input_values,
                    "Predicted Expenditure (Lakhs)": result["prediction"],
                    "Category": result["category"]
                }
                st.session_state.prediction_history.append(history_entry)
                
                # Report Download
                import pandas as pd
                report_data = {**input_values, "PREDICTED_EXPENDITURE_LAKHS": result["prediction"], "CATEGORY": result["category"]}
                report_df = pd.DataFrame([report_data])
                csv_output = report_df.to_csv(index=False).encode('utf-8')
                st.download_button(
                    label="📥 Download Prediction Report (CSV)",
                    data=csv_output,
                    file_name='single_prediction_report.csv',
                    mime='text/csv',
                    use_container_width=True
                )

            except Exception as e:
                import logging
                logging.getLogger(__name__).exception("Prediction failed: %s", e)
                st.error(f"Prediction failed: {e}")

        else:
            _render_waiting_card()

            # Quick guide
            with st.expander("💡 How to use", expanded=True):
                st.markdown("""
                1. Fill in all **10 project parameters** on the left
                2. Click **🔮 Predict Expenditure**
                3. The predicted expenditure and its category will appear here

                **Categories:**
                - ✅ **Low** — Under ₹500 Lakhs
                - ⚠️ **Medium** — ₹500 – ₹2,000 Lakhs
                - 🔴 **High** — Above ₹2,000 Lakhs
                """)

    # ── Session History ──
    if st.session_state.get("prediction_history"):
        st.markdown("<hr>", unsafe_allow_html=True)
        st.markdown('<div class="section-header">🕒 Prediction History (Current Session)</div>', unsafe_allow_html=True)
        
        history_df = pd.DataFrame(st.session_state.prediction_history)
        st.dataframe(history_df, use_container_width=True)
        
        hc1, hc2, _ = st.columns([1, 1, 2])
        with hc1:
            if st.button("🗑️ Clear History", use_container_width=True):
                st.session_state.prediction_history = []
                st.rerun()
        with hc2:
            history_csv = history_df.to_csv(index=False).encode('utf-8')
            st.download_button(
                label="📥 Download History (CSV)",
                data=history_csv,
                file_name='prediction_history.csv',
                mime='text/csv',
                use_container_width=True
            )
