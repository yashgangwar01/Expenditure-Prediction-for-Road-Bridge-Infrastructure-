"""
Model_Comparison.py
-------------------
Compares all trained models across multiple metrics.
Provides interactive tables, bar charts, radar charts, actual vs predicted plots,
residual plots, and CSV download capabilities.
"""

import sys
from pathlib import Path
from typing import Any, Dict

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

_SRC_APP = str(Path(__file__).resolve().parent.parent)
if _SRC_APP not in sys.path:
    sys.path.insert(0, _SRC_APP)

import config
from utils.visualization import (
    plot_model_comparison,
    plot_actual_vs_predicted,
    plot_residuals,
)

# ═══════════════════════════════════════════════════
#  CUSTOM PLOTS
# ═══════════════════════════════════════════════════
def plot_radar_chart(metrics_df: pd.DataFrame) -> go.Figure:
    """Create a radar chart comparing models across different scaled metrics."""
    # We need to normalize metrics to 0-1 scale so they fit on the same radar plot
    # For R2 and CV, higher is better (already 0-1 generally, but min-max is safer).
    # For error metrics (MAE, RMSE, MAPE), lower is better. We invert them.
    
    categories = ['R²', 'CV R²', '1/MAE', '1/RMSE', '1/MAPE']
    
    fig = go.Figure()
    
    for idx, row in metrics_df.iterrows():
        # Min-Max scale values for the radar
        r2 = row['R²']
        cv = row['CV Mean']
        # Use relative inverse for errors
        inv_mae = 1.0 / (row['MAE'] + 1e-5)
        inv_rmse = 1.0 / (row['RMSE'] + 1e-5)
        inv_mape = 1.0 / (row['MAPE (%)'] + 1e-5)
        
        values = [r2, cv, inv_mae, inv_rmse, inv_mape]
        
        # We need to scale these to a relative 0-1 across models so radar looks nice
        # We'll just plot the raw/inverse values but normalized by the column max
        
        fig.add_trace(go.Scatterpolar(
            r=values,
            theta=categories,
            fill='toself',
            name=row['Model'],
            opacity=0.6,
            visible='legendonly' if idx > 2 else True # Show top 3 by default
        ))

    fig.update_layout(
        polar=dict(
            radialaxis=dict(visible=False, range=[0, max(values)*1.2] if values else [0, 1]),
            bgcolor='rgba(0,0,0,0)'
        ),
        showlegend=True,
        title="Model Performance Radar (Relative Scale)",
        paper_bgcolor='rgba(0,0,0,0)',
        font=dict(color='white')
    )
    return fig


# ═══════════════════════════════════════════════════
#  MAIN RENDER
# ═══════════════════════════════════════════════════
def render(artifacts: Dict[str, Any]) -> None:
    """Render the Model Comparison page."""
    
    st.markdown("""
    <div style="margin-bottom:1.5rem;">
        <h2 style="margin:0; color:#F8FAFC;">
            📈 Model Comparison
        </h2>
        <p style="color:#94A3B8; margin-top:0.3rem;">
            Compare the performance of all trained machine learning models.
        </p>
    </div>
    """, unsafe_allow_html=True)

    metadata = artifacts["metadata"]
    model_metrics = metadata["model_metrics"]
    best_model_name = metadata["best_model"]
    
    # ── Compile Metrics DataFrame ──
    rows = []
    for model_name, m in model_metrics.items():
        rows.append({
            "Model": model_name,
            "R²": m["R2"],
            "CV Mean": m["cv_mean"],
            "MAE": m["MAE"],
            "RMSE": m["RMSE"],
            "MAPE (%)": m["MAPE"],
            "Train Time (s)": m.get("fit_time", 0.0),
            "Predict Time (s)": m.get("pred_time", 0.0),
        })
        
    df_metrics = pd.DataFrame(rows)
    df_metrics = df_metrics.sort_values(by="R²", ascending=False).reset_index(drop=True)
    
    # ── Model Ranking Highlight ──
    st.markdown('<div class="section-header">🏆 Model Rankings</div>', unsafe_allow_html=True)
    
    cols = st.columns(3)
    for i, col in enumerate(cols):
        if i < len(df_metrics):
            m_row = df_metrics.iloc[i]
            medals = ["🥇", "🥈", "🥉"]
            border_color = ["#FBBF24", "#94A3B8", "#B45309"][i]
            col.markdown(f"""
            <div style="background:rgba(30,41,59,0.5); border:1px solid {border_color}; 
                        border-radius:12px; padding:1.2rem; text-align:center;">
                <div style="font-size:2rem; margin-bottom:0.5rem;">{medals[i]}</div>
                <div style="font-size:1.1rem; font-weight:700; color:#F8FAFC;">{m_row['Model']}</div>
                <div style="font-size:0.9rem; color:#A5B4FC; margin-top:0.4rem;">
                    R² = {m_row['R²']:.4f}
                </div>
            </div>
            """, unsafe_allow_html=True)

    # ── Interactive Comparison Table ──
    st.markdown('<div class="section-header">📊 Detailed Metrics Table</div>', unsafe_allow_html=True)
    
    # Format for display
    display_df = df_metrics.copy()
    display_df["R²"] = display_df["R²"].map("{:.4f}".format)
    display_df["CV Mean"] = display_df["CV Mean"].map("{:.4f}".format)
    display_df["MAE"] = display_df["MAE"].map("{:.4f}".format)
    display_df["RMSE"] = display_df["RMSE"].map("{:.4f}".format)
    display_df["MAPE (%)"] = display_df["MAPE (%)"].map("{:.2f}%".format)
    display_df["Train Time (s)"] = display_df["Train Time (s)"].map("{:.4f}".format)
    display_df["Predict Time (s)"] = display_df["Predict Time (s)"].map("{:.4f}".format)
    
    st.dataframe(display_df, use_container_width=True)
    
    # CSV Download
    csv = df_metrics.to_csv(index=False).encode('utf-8')
    st.download_button(
        label="📥 Download Model Comparison Report (CSV)",
        data=csv,
        file_name='model_comparison_report.csv',
        mime='text/csv',
    )

    # ── Interactive Bar Charts ──
    st.markdown('<div class="section-header">📈 Performance Charts</div>', unsafe_allow_html=True)
    
    metric_choice = st.selectbox(
        "Select Metric to Visualize:",
        ["R2", "cv_mean", "MAE", "RMSE", "MAPE", "fit_time", "pred_time"]
    )
    
    st.plotly_chart(
        plot_model_comparison(model_metrics, metric_name=metric_choice, title=f"Model Comparison — {metric_choice}"),
        use_container_width=True
    )

    # ── Radar Chart ──
    st.markdown('<div class="section-header">🕸️ Radar Chart</div>', unsafe_allow_html=True)
    st.plotly_chart(plot_radar_chart(df_metrics), use_container_width=True)

    # ── Actual vs Predicted & Residuals ──
    st.markdown('<div class="section-header">🔍 Prediction Analysis</div>', unsafe_allow_html=True)
    
    all_models = artifacts.get("all_models", {})
    if not all_models:
        st.warning("Model objects not found in artifacts. Cannot generate prediction plots.")
        return
        
    selected_model_name = st.selectbox("Select Model for Analysis:", df_metrics["Model"].tolist())
    
    # We need to run predictions for the selected model. 
    # Let's import the preprocessing pipeline to get the test set.
    from utils.preprocessing import preprocess_pipeline
    from sklearn.model_selection import train_test_split
    
    with st.spinner(f"Generating plots for {selected_model_name}..."):
        # Quick data load and split (matches training.py)
        X_scaled, y, _, _, _ = preprocess_pipeline()
        _, X_test, _, y_test = train_test_split(
            X_scaled, y, 
            test_size=config.TEST_SIZE, 
            random_state=config.RANDOM_STATE
        )
        
        model_obj = all_models[selected_model_name]
        
        if selected_model_name == "Polynomial Regression":
            poly_t = artifacts.get("polynomial")
            if poly_t is not None:
                X_test_trans = poly_t.transform(X_test)
                preds = model_obj.predict(X_test_trans)
            else:
                st.error("Polynomial transformer missing.")
                preds = np.zeros(len(y_test))
        else:
            preds = model_obj.predict(X_test)
        
        pcol1, pcol2 = st.columns(2)
        with pcol1:
            st.plotly_chart(
                plot_actual_vs_predicted(y_test, preds, selected_model_name),
                use_container_width=True
            )
        with pcol2:
            st.plotly_chart(
                plot_residuals(y_test, preds, selected_model_name),
                use_container_width=True
            )
