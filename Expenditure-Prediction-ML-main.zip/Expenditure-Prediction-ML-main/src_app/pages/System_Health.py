"""
System_Health.py
----------------
Displays system health indicators, version numbers, and artifact loading status.
"""

import sys
import platform
from pathlib import Path
from typing import Any, Dict

import streamlit as st

_SRC_APP = str(Path(__file__).resolve().parent.parent)
if _SRC_APP not in sys.path:
    sys.path.insert(0, _SRC_APP)

import config
import sklearn
import pandas as pd
import numpy as np
try:
    import xgboost
    XGB_VER = xgboost.__version__
except:
    XGB_VER = "Not Installed"

try:
    import shap
    SHAP_VER = shap.__version__
except:
    SHAP_VER = "Not Installed"

def _status_indicator(is_ok: bool, text: str) -> str:
    color = "#10B981" if is_ok else "#EF4444"
    icon = "✅" if is_ok else "❌"
    return f'<div style="color:{color}; font-weight:600;">{icon} {text}</div>'

def render(artifacts: Dict[str, Any]) -> None:
    """Render the System Health page."""
    
    st.markdown("""
    <div style="margin-bottom:1.5rem;">
        <h2 style="margin:0; color:#F8FAFC;">
            🩺 System Health
        </h2>
        <p style="color:#94A3B8; margin-top:0.3rem;">
            Application status, library versions, and artifact health.
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown('<div class="section-header">📦 Environment Versions</div>', unsafe_allow_html=True)
        st.markdown(f"**Python**: {platform.python_version()}")
        st.markdown(f"**Streamlit**: {st.__version__}")
        st.markdown(f"**Pandas**: {pd.__version__}")
        st.markdown(f"**NumPy**: {np.__version__}")
        st.markdown(f"**Scikit-Learn**: {sklearn.__version__}")
        st.markdown(f"**XGBoost**: {XGB_VER}")
        st.markdown(f"**SHAP**: {SHAP_VER}")
        
    with col2:
        st.markdown('<div class="section-header">🛠️ Artifact Status</div>', unsafe_allow_html=True)
        
        has_model = "model" in artifacts and artifacts["model"] is not None
        has_scaler = "scaler" in artifacts and artifacts["scaler"] is not None
        has_meta = "metadata" in artifacts and artifacts["metadata"] is not None
        has_features = "feature_names" in artifacts and artifacts["feature_names"] is not None
        
        st.markdown(_status_indicator(has_model, "Model Loaded"), unsafe_allow_html=True)
        st.markdown(_status_indicator(has_scaler, "Scaler Loaded"), unsafe_allow_html=True)
        st.markdown(_status_indicator(has_meta, "Metadata Loaded"), unsafe_allow_html=True)
        st.markdown(_status_indicator(has_features, "Feature Names Loaded"), unsafe_allow_html=True)
        
        # Dataset check
        dataset_ok = config.DATASET_PATH.exists()
        st.markdown(_status_indicator(dataset_ok, "Dataset Available"), unsafe_allow_html=True)
        
    st.markdown("<hr>", unsafe_allow_html=True)
    
    st.markdown('<div class="section-header">📝 Application Info</div>', unsafe_allow_html=True)
    meta = artifacts.get("metadata", {})
    
    st.markdown(f"**Application Version:** v{config.APP_VERSION}")
    st.markdown(f"**Model Version:** v{config.MODEL_VERSION}")
    st.markdown(f"**Last Training Date:** {meta.get('training_timestamp', 'Unknown')}")
