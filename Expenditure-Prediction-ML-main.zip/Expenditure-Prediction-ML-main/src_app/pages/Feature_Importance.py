"""
Feature_Importance.py
---------------------
Displays feature importances for tree-based models and optionally SHAP plots.
"""

import sys
from pathlib import Path
from typing import Any, Dict

import numpy as np
import pandas as pd
import streamlit as st
import plotly.graph_objects as go

_SRC_APP = str(Path(__file__).resolve().parent.parent)
if _SRC_APP not in sys.path:
    sys.path.insert(0, _SRC_APP)

import config
from utils.visualization import plot_feature_importance
from utils.preprocessing import preprocess_pipeline
from sklearn.model_selection import train_test_split

try:
    import shap
    SHAP_AVAILABLE = True
except ImportError:
    SHAP_AVAILABLE = False


def render(artifacts: Dict[str, Any]) -> None:
    """Render the Feature Importance page."""
    
    st.markdown("""
    <div style="margin-bottom:1.5rem;">
        <h2 style="margin:0; color:#F8FAFC;">
            🎯 Feature Importance
        </h2>
        <p style="color:#94A3B8; margin-top:0.3rem;">
            Understand which project parameters drive the expenditure predictions.
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    all_models = artifacts.get("all_models", {})
    if not all_models:
        st.error("No models found in artifacts. Please run training first.")
        return
        
    metadata = artifacts.get("metadata", {})
    
    # Filter only models that have feature_importances_
    tree_models = {}
    for name, model in all_models.items():
        if hasattr(model, "feature_importances_"):
            tree_models[name] = model
            
    if not tree_models:
        st.warning("No tree-based models found that support feature importance.")
        return
        
    # Feature names
    feature_names = artifacts.get("feature_names")
    if feature_names is None:
        try:
            from utils.helpers import load_json
            feature_names = load_json(config.MODELS_DIR / "feature_names.json")
        except:
            feature_names = config.NUMERIC_FEATURES
            
    # --- Select Model ---
    selected_model_name = st.selectbox(
        "Select Model for Feature Importance Analysis:", 
        list(tree_models.keys()), 
        index=0
    )
    selected_model = tree_models[selected_model_name]
    importances = selected_model.feature_importances_
    
    # --- SHAP Analysis ---
    st.markdown('<div class="section-header">💡 Advanced Explainability</div>', unsafe_allow_html=True)
    
    exp_tab1, exp_tab2, exp_tab3 = st.tabs(["Tree Importance (Built-in)", "Permutation Importance", "Partial Dependence Plots"])
    
    with exp_tab1:
        st.markdown(f"**Model:** {selected_model_name}")
        fig = plot_feature_importance(importances, feature_names, selected_model_name)
        st.plotly_chart(fig, use_container_width=True)
        st.markdown("""
        <div class="glass-card">
            <h4 style="color:#F1F5F9; margin-top:0;">Interpretation</h4>
            <p style="color:#CBD5E1; line-height:1.6; font-size:0.9rem; margin-bottom:0;">
                Features with longer bars are the most critical in determining the final predicted expenditure. 
                For example, <b>COST_OF_WORKS_SANCTIONED_LAKHS</b> often dominates because it acts as an anchor for actual expenditure.
            </p>
        </div>
        """, unsafe_allow_html=True)

    with exp_tab2:
        st.markdown(f"**Permutation Importance for {selected_model_name}**")
        from sklearn.inspection import permutation_importance
        with st.spinner("Calculating Permutation Importance..."):
            X_scaled, y, _, _, _ = preprocess_pipeline()
            # We use a small random subset to compute permutation importance quickly
            X_sample, _, y_sample, _ = train_test_split(X_scaled, y, train_size=min(500, len(X_scaled)), random_state=42)
            perm_result = permutation_importance(selected_model, X_sample, y_sample, n_repeats=10, random_state=42, n_jobs=-1)
            
            perm_sorted_idx = perm_result.importances_mean.argsort()
            perm_importances = perm_result.importances_mean[perm_sorted_idx]
            perm_names = [feature_names[i] for i in perm_sorted_idx]
            
            fig_perm = go.Figure(go.Bar(
                x=perm_importances,
                y=perm_names,
                orientation='h',
                marker=dict(color="#10B981")
            ))
            fig_perm.update_layout(
                title="Permutation Feature Importance",
                xaxis_title="Decrease in Accuracy / R2",
                yaxis_title="Feature",
                template="plotly_dark",
                paper_bgcolor="rgba(0,0,0,0)",
                plot_bgcolor="rgba(0,0,0,0)"
            )
            st.plotly_chart(fig_perm, use_container_width=True)
            
            st.markdown("""
            <div class="glass-card">
                <h4 style="color:#F1F5F9; margin-top:0;">Interpretation</h4>
                <p style="color:#CBD5E1; line-height:1.6; font-size:0.9rem; margin-bottom:0;">
                    Permutation importance measures the decrease in model performance when a single feature value is randomly shuffled. 
                    A higher drop means the model relies heavily on that feature.
                </p>
            </div>
            """, unsafe_allow_html=True)
            
    with exp_tab3:
        st.markdown(f"**Partial Dependence Plots (PDP) for {selected_model_name}**")
        from sklearn.inspection import PartialDependenceDisplay
        import matplotlib.pyplot as plt
        
        st.markdown("Select a feature to see how it affects the predicted expenditure on average.")
        pdp_feature = st.selectbox("Feature for PDP", feature_names)
        
        with st.spinner(f"Generating PDP for {pdp_feature}..."):
            X_scaled, y, _, _, _ = preprocess_pipeline()
            X_df = pd.DataFrame(X_scaled, columns=feature_names)
            fig_pdp, ax_pdp = plt.subplots(figsize=(8, 5))
            fig_pdp.patch.set_facecolor('none')
            ax_pdp.set_facecolor('none')
            ax_pdp.tick_params(colors='white')
            ax_pdp.xaxis.label.set_color('white')
            ax_pdp.yaxis.label.set_color('white')
            
            PartialDependenceDisplay.from_estimator(
                selected_model, 
                X_df, 
                [pdp_feature], 
                ax=ax_pdp,
                line_kw={"color": "#6366F1", "linewidth": 2}
            )
            st.pyplot(fig_pdp, transparent=True)
            
            st.markdown("""
            <div class="glass-card">
                <h4 style="color:#F1F5F9; margin-top:0;">Interpretation</h4>
                <p style="color:#CBD5E1; line-height:1.6; font-size:0.9rem; margin-bottom:0;">
                    Partial Dependence Plots show the marginal effect one feature has on the predicted outcome of a machine learning model.
                    The y-axis represents the predicted expenditure, and the x-axis is the feature value. 
                    A flat line indicates no dependence, while a sloping line shows correlation.
                </p>
            </div>
            """, unsafe_allow_html=True)

    # --- SHAP Analysis ---
    st.markdown('<div class="section-header">🧠 SHAP Analysis (Local & Global)</div>', unsafe_allow_html=True)
    
    if not SHAP_AVAILABLE:
        st.warning("SHAP library is not installed. Run `pip install shap` to view SHAP plots.")
        return
        
    with st.spinner(f"Computing SHAP values for {selected_model_name}..."):
        try:
            # Need a sample of data for SHAP
            X_scaled, y, _, _, _ = preprocess_pipeline(csv_path=str(config.DATASET_PATH))
            X_train, X_test, y_train, y_test = train_test_split(
                X_scaled, y, 
                test_size=config.TEST_SIZE, 
                random_state=config.RANDOM_STATE
            )
            
            # Subsample for speed
            sample_size = min(200, X_test.shape[0])
            np.random.seed(42)
            indices = np.random.choice(X_test.shape[0], sample_size, replace=False)
            X_sample = X_test[indices]
            
            # Compute SHAP
            explainer = shap.TreeExplainer(selected_model)
            shap_values = explainer.shap_values(X_sample)
            
            # Handle list output (sometimes for XGBoost/RF in newer SHAP)
            if isinstance(shap_values, list):
                shap_values = shap_values[1] # Assume binary or continuous, index 1 or 0
                
            X_sample_df = pd.DataFrame(X_sample, columns=feature_names)
            
            tab1, tab2 = st.tabs(["SHAP Summary Plot", "SHAP Waterfall Plot (Single Prediction)"])
            
            with tab1:
                st.markdown("The Summary Plot shows both the magnitude and direction of a feature's effect on the prediction.")
                # We use matplotlib for SHAP summary plot as it is native to SHAP
                import matplotlib.pyplot as plt
                
                fig, ax = plt.subplots(figsize=(10, 6))
                # Set transparent background
                fig.patch.set_facecolor('none')
                ax.set_facecolor('none')
                
                # Plot
                shap.summary_plot(shap_values, X_sample_df, show=False, plot_size=(10, 6))
                
                # Customize axes colors for dark theme
                ax.xaxis.label.set_color('white')
                ax.yaxis.label.set_color('white')
                ax.tick_params(colors='white')
                for spine in ax.spines.values():
                    spine.set_edgecolor('white')
                    
                st.pyplot(fig, clear_figure=True)
                
            with tab2:
                st.markdown("The Waterfall Plot explains a **single prediction**, showing how each feature pushes the model output from the base value to the final prediction.")
                
                # Pick a random instance
                instance_idx = st.slider("Select Sample Index for Local Explanation", 0, sample_size - 1, 0)
                
                fig_waterfall, ax_waterfall = plt.subplots(figsize=(8, 6))
                fig_waterfall.patch.set_facecolor('none')
                ax_waterfall.set_facecolor('none')
                
                # Create an Explanation object for the waterfall plot
                explanation = shap.Explanation(
                    values=shap_values[instance_idx], 
                    base_values=explainer.expected_value, 
                    data=X_sample_df.iloc[instance_idx].values,
                    feature_names=feature_names
                )
                
                shap.waterfall_plot(explanation, show=False)
                
                ax_waterfall.xaxis.label.set_color('white')
                ax_waterfall.yaxis.label.set_color('white')
                ax_waterfall.tick_params(colors='white')
                
                st.pyplot(fig_waterfall, clear_figure=True)
                
        except Exception as e:
            st.error(f"Error computing SHAP values for {selected_model_name}: {e}")
