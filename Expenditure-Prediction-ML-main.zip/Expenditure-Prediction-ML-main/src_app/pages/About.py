"""
About.py
--------
Information about the project, the ML workflow, technology stack, and author.
"""

import streamlit as st
import config

def render(artifacts: dict) -> None:
    """Render the About page."""
    
    st.markdown("""
    <div style="margin-bottom:1.5rem;">
        <h2 style="margin:0; color:#F8FAFC;">
            ℹ️ About the Project
        </h2>
        <p style="color:#94A3B8; margin-top:0.3rem;">
            Details regarding the dataset, machine learning workflow, and the developer.
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    tab1, tab2, tab3 = st.tabs(["Project Overview", "Technology & ML", "Author Info"])
    
    with tab1:
        st.markdown('<div class="section-header">🌍 Project Overview</div>', unsafe_allow_html=True)
        st.markdown("""
        <div class="glass-card">
            <p style="color:#CBD5E1; line-height:1.7;">
                The <strong>Road Infrastructure Expenditure Prediction System</strong> is designed to estimate the financial requirements for road and bridge construction projects, primarily inspired by rural development schemes like PMGSY (Pradhan Mantri Gram Sadak Yojana) in India.
            </p>
            <p style="color:#CBD5E1; line-height:1.7;">
                By utilizing historical data on sanctioned works, completed lengths, and estimated costs, the system employs advanced Machine Learning algorithms to predict the actual <strong>Expenditure Occurred</strong>. This helps policymakers and project managers allocate budgets more efficiently and monitor financial progress.
            </p>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown('<div class="section-header">📂 Dataset Description</div>', unsafe_allow_html=True)
        st.markdown("""
        The dataset contains aggregated information at the district level regarding various road infrastructure projects.
        Key features include:
        * **Sanctioned Works**: Count and length of roads/bridges approved.
        * **Completed Works**: Count and length of roads/bridges finished.
        * **Balance Works**: Works that are still pending.
        * **Sanctioned Cost**: The estimated budget allocated.
        * **Expenditure Occurred (Target)**: The actual money spent.
        """)
        
        st.markdown('<div class="section-header">📁 Folder Structure</div>', unsafe_allow_html=True)
        st.code("""
Road_Infrastructure_Expenditure_Prediction/
├── app.py/
│   ├── data/                      (Raw Dataset)
│   ├── logs/                      (Application Logs)
│   ├── tests/                     (Pytest Test Suites)
│   ├── screenshots/               (Images for README)
│   ├── .github/workflows/         (CI/CD Pipeline)
│   ├── src_app/                   (Source Code)
│   │   ├── app.py                 (Main Streamlit Application)
│   │   ├── config.py              (Configuration & Constants)
│   │   ├── train_models.py        (Standalone Training Script)
│   │   ├── pages/                 (Streamlit Pages)
│   │   ├── utils/                 (Helper Modules)
│   │   └── models/                (Saved Joblib Artifacts)
│   ├── Dockerfile                 (Docker Configuration)
│   ├── docker-compose.yml         (Docker Compose Configuration)
│   ├── requirements.txt           (Python Dependencies)
│   └── README.md                  (Project Documentation)
        """, language="text")

    with tab2:
        st.markdown('<div class="section-header">⚙️ Machine Learning Workflow</div>', unsafe_allow_html=True)
        st.markdown("""
        1. **Data Preprocessing**: Handling missing values using median imputation and removing outliers via the Interquartile Range (IQR) method.
        2. **Feature Scaling**: Normalizing features using `MinMaxScaler` to ensure uniform contribution.
        3. **Model Training**: Training a suite of regression models including Linear Regression, Decision Trees, KNN, SVR, Random Forest, Gradient Boosting, and XGBoost.
        4. **Hyperparameter Tuning**: Optimizing model parameters using `RandomizedSearchCV` with 5-fold cross-validation.
        5. **Evaluation**: Assessing models based on R², MAE, RMSE, and MAPE.
        6. **Deployment**: Exporting the best model and scaler using `joblib` for real-time web application inference.
        """)
        
        st.markdown('<div class="section-header">🛠️ Technology Stack</div>', unsafe_allow_html=True)
        cols = st.columns(3)
        with cols[0]:
            st.markdown("""
            **Core Python**
            * Python 3
            * Pandas
            * NumPy
            """)
        with cols[1]:
            st.markdown("""
            **Machine Learning**
            * Scikit-Learn
            * XGBoost
            * SHAP
            """)
        with cols[2]:
            st.markdown("""
            **Web & Viz**
            * Streamlit
            * Plotly
            * Matplotlib/Seaborn
            """)
            
        st.markdown('<div class="section-header">🚀 Future Scope</div>', unsafe_allow_html=True)
        st.markdown("""
        * **Deep Learning**: Integration of Neural Networks for complex non-linear relationships.
        * **Time-Series Analysis**: Forecasting future expenditure trends across financial years.
        * **Geospatial Analysis**: Mapping district-level expenditure on interactive maps.
        * **Automated Retraining**: Setting up a pipeline to automatically retrain the model when new data is uploaded.
        """)

    with tab3:
        st.markdown('<div class="section-header">👨‍💻 Author Information</div>', unsafe_allow_html=True)
        
        st.markdown(f"""
        <div class="glass-card" style="text-align:center;">
            <div style="font-size:4rem; margin-bottom:1rem;">👨‍🎓</div>
            <h3 style="margin:0; color:#F8FAFC;">{config.AUTHOR_NAME}</h3>
            <p style="color:#94A3B8; font-size:1.1rem; margin-top:0.3rem;">{config.AUTHOR_ROLL}</p>
        </div>
        """, unsafe_allow_html=True)

        st.markdown('<div class="section-header">📊 Project Metadata</div>', unsafe_allow_html=True)
        
        metadata = artifacts.get("metadata", {})
        
        c1, c2 = st.columns(2)
        with c1:
            st.markdown(f"**Best Model**: {metadata.get('best_model', 'N/A')}")
            st.markdown(f"**Training Date**: {metadata.get('training_timestamp', 'N/A')}")
            st.markdown(f"**Dataset Rows**: {metadata.get('dataset_rows', 'N/A')}")
            st.markdown(f"**Dataset Columns**: {metadata.get('dataset_cols', 'N/A')}")
        with c2:
            st.markdown(f"**Application Version**: {metadata.get('app_version', config.APP_VERSION)}")
            st.markdown(f"**Model Version**: {metadata.get('model_version', config.MODEL_VERSION)}")
            st.markdown(f"**Best R²**: {metadata.get('best_r2', 0):.4f}")
            st.markdown(f"**Best MAPE**: {metadata.get('best_mape', 0):.2f}%")
