"""
Dataset_Analysis.py
-------------------
Exploratory Data Analysis page.
Provides dataset previews, missing value summaries, descriptive statistics,
correlation heatmaps, distributions, boxplots, scatter plots, and pair plots.
"""

import sys
from pathlib import Path
from typing import Any, Dict

import pandas as pd
import streamlit as st

_SRC_APP = str(Path(__file__).resolve().parent.parent)
if _SRC_APP not in sys.path:
    sys.path.insert(0, _SRC_APP)

import config
from utils.logger import get_logger
from utils.preprocessing import preprocess_pipeline, load_data
from utils.visualization import (
    plot_correlation_heatmap,
    plot_distribution,
    plot_boxplot,
    plot_scatter,
    plot_pairplot,
)

logger = get_logger(__name__)

# ═══════════════════════════════════════════════════
#  DATA LOADING
# ═══════════════════════════════════════════════════
@st.cache_data(show_spinner=False)
def load_and_preprocess_data():
    """Load the dataset and return raw, clean, and scaling artifacts."""
    df_full = load_data()
    _, _, _, df_clean, df_raw = preprocess_pipeline()
    return df_full, df_raw, df_clean

def render(artifacts: Dict[str, Any]) -> None:
    """Render the Dataset Analysis page."""
    logger.info("Rendering Dataset Analysis page.")

    st.markdown("""
    <div style="margin-bottom:1.5rem;">
        <h2 style="margin:0; color:#F8FAFC;">
            📊 Dataset Analysis
        </h2>
        <p style="color:#94A3B8; margin-top:0.3rem;">
            Exploratory Data Analysis (EDA) of the Road Infrastructure Dataset.
        </p>
    </div>
    """, unsafe_allow_html=True)

    with st.spinner("Loading dataset..."):
        try:
            df_full, df_raw, df_clean = load_and_preprocess_data()
        except FileNotFoundError as exc:
            logger.error("Dataset not found: %s", exc)
            st.error(f"Dataset not found at `{config.DATASET_PATH}`.")
            st.stop()
        except Exception as e:
            logger.exception("Error loading dataset: %s", e)
            st.error(f"Error loading dataset: {e}")
            st.stop()

    # ── Sidebar Filters ──
    st.sidebar.markdown("### 🔍 Filter Data")
    
    # State Filter
    all_states = ["All"] + sorted(df_full["STATE_NAME"].dropna().unique().tolist())
    selected_state = st.sidebar.selectbox("State", all_states)
    
    # District Filter
    if selected_state != "All":
        districts = ["All"] + sorted(df_full[df_full["STATE_NAME"] == selected_state]["DISTRICT_NAME"].dropna().unique().tolist())
    else:
        districts = ["All"] + sorted(df_full["DISTRICT_NAME"].dropna().unique().tolist())
    selected_district = st.sidebar.selectbox("District", districts)
    
    # Cost Range Filter (using raw cost column)
    min_cost = float(df_full["COST_OF_WORKS_SANCTIONED_LAKHS"].min())
    max_cost = float(df_full["COST_OF_WORKS_SANCTIONED_LAKHS"].max())
    selected_cost = st.sidebar.slider("Sanctioned Cost Range (Lakhs)", min_value=min_cost, max_value=max_cost, value=(min_cost, max_cost))
    
    # Road Length Filter
    min_len = float(df_full["LENGTH_OF_ROAD_WORK_SANCTIONED_KM"].min())
    max_len = float(df_full["LENGTH_OF_ROAD_WORK_SANCTIONED_KM"].max())
    selected_length = st.sidebar.slider("Sanctioned Length (KM)", min_value=min_len, max_value=max_len, value=(min_len, max_len))
    
    # Filter the dataset
    mask = pd.Series([True] * len(df_full), index=df_full.index)
    if selected_state != "All":
        mask &= (df_full["STATE_NAME"] == selected_state)
    if selected_district != "All":
        mask &= (df_full["DISTRICT_NAME"] == selected_district)
    
    mask &= (df_full["COST_OF_WORKS_SANCTIONED_LAKHS"] >= selected_cost[0]) & (df_full["COST_OF_WORKS_SANCTIONED_LAKHS"] <= selected_cost[1])
    mask &= (df_full["LENGTH_OF_ROAD_WORK_SANCTIONED_KM"] >= selected_length[0]) & (df_full["LENGTH_OF_ROAD_WORK_SANCTIONED_KM"] <= selected_length[1])
    
    df_full_filtered = df_full[mask].copy()
    
    # Map index filtering back to df_clean and df_raw using intersection of indices
    df_raw_filtered = df_raw.loc[df_raw.index.intersection(df_full_filtered.index)]
    df_clean_filtered = df_clean.loc[df_clean.index.intersection(df_full_filtered.index)]
    
    df_full, df_raw, df_clean = df_full_filtered, df_raw_filtered, df_clean_filtered

    # ── Dataset Overview ──
    st.markdown('<div class="section-header">📁 Dataset Overview</div>', unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Raw Dataset Shape", f"{df_full.shape[0]} × {df_full.shape[1]}")
    with col2:
        st.metric("Cleaned Dataset Shape", f"{df_clean.shape[0]} × {df_clean.shape[1]}")
    with col3:
        st.metric("Features Used", str(len(config.ALL_COLUMNS) - 1))

    view_option = st.radio(
        "Select Dataset View:",
        ["Cleaned Dataset (Used for Modeling)", "Raw Dataset (Numeric Columns)", "Full Original Dataset"],
        horizontal=True
    )

    if "Cleaned" in view_option:
        st.dataframe(df_clean, use_container_width=True)
        current_df = df_clean
    elif "Raw Dataset (Numeric" in view_option:
        st.dataframe(df_raw, use_container_width=True)
        current_df = df_raw
    else:
        st.dataframe(df_full, use_container_width=True)
        current_df = df_full

    # ── Missing Values & Statistics ──
    st.markdown('<div class="section-header">📈 Descriptive Statistics & Missing Values</div>', unsafe_allow_html=True)
    
    tab1, tab2 = st.tabs(["Descriptive Statistics", "Missing Values"])
    
    with tab1:
        st.dataframe(current_df.describe(), use_container_width=True)
        
    with tab2:
        missing = current_df.isnull().sum()
        missing_df = pd.DataFrame({"Missing Values": missing, "Percentage (%)": (missing / len(current_df)) * 100})
        missing_df = missing_df[missing_df["Missing Values"] > 0].sort_values("Missing Values", ascending=False)
        
        if len(missing_df) == 0:
            st.success("No missing values in this dataset view!")
        else:
            st.warning(f"Found {missing.sum()} missing values across {len(missing_df)} columns.")
            st.dataframe(missing_df, use_container_width=True)

    # ── Target Variable Distribution ──
    st.markdown('<div class="section-header">🎯 Target Variable Distribution</div>', unsafe_allow_html=True)
    st.plotly_chart(
        plot_distribution(df_clean, config.TARGET_COLUMN, nbins=50),
        use_container_width=True
    )

    # ── Correlation Heatmap ──
    st.markdown('<div class="section-header">🔥 Correlation Heatmap</div>', unsafe_allow_html=True)
    st.plotly_chart(
        plot_correlation_heatmap(df_clean),
        use_container_width=True
    )

    # ── Feature Distributions & Boxplots ──
    st.markdown('<div class="section-header">📊 Feature Analysis</div>', unsafe_allow_html=True)
    
    available_features = [c for c in df_clean.columns if c != config.TARGET_COLUMN]
    selected_feature = st.selectbox("Select Feature to Analyze:", available_features)
    
    col_dist, col_box = st.columns(2)
    with col_dist:
        st.plotly_chart(
            plot_distribution(df_clean, selected_feature, nbins=40),
            use_container_width=True
        )
    with col_box:
        st.plotly_chart(
            plot_boxplot(df_clean, [selected_feature, config.TARGET_COLUMN]),
            use_container_width=True
        )

    # ── Scatter Plots ──
    st.markdown('<div class="section-header">📍 Feature Relationships (Scatter Plots)</div>', unsafe_allow_html=True)
    
    sc_col1, sc_col2 = st.columns(2)
    with sc_col1:
        x_feature = st.selectbox("X-Axis Feature:", available_features, index=0)
    with sc_col2:
        y_feature = st.selectbox(
            "Y-Axis Feature:",
            [config.TARGET_COLUMN] + available_features,
            index=0
        )
        
    st.plotly_chart(
        plot_scatter(df_clean, x_feature, y_feature, trendline=True),
        use_container_width=True
    )

    # ── Pair Plot ──
    st.markdown('<div class="section-header">🧩 Pair Plot Analysis</div>', unsafe_allow_html=True)
    
    default_pair_features = available_features[:3] + [config.TARGET_COLUMN]
    selected_pair_features = st.multiselect(
        "Select features for Pair Plot (max 5 recommended):",
        df_clean.columns,
        default=default_pair_features
    )
    
    if len(selected_pair_features) >= 2:
        if len(selected_pair_features) > 6:
            st.warning("Selecting more than 6 features may cause performance issues and cluttered plots.")
            
        with st.spinner("Generating Pair Plot..."):
            st.plotly_chart(
                plot_pairplot(df_clean, selected_pair_features),
                use_container_width=True
            )
    else:
        st.info("Please select at least 2 features to generate a pair plot.")

