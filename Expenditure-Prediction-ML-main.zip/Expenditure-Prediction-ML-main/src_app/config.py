"""
config.py
─────────
Central configuration for the Road Infrastructure Expenditure Prediction System.
All paths, feature definitions, hyperparameters, and UI settings live here.
"""

from pathlib import Path
from typing import Dict, List, Tuple

# ═══════════════════════════════════════════════════
#  PATH CONFIGURATION
# ═══════════════════════════════════════════════════
BASE_DIR: Path = Path(__file__).resolve().parent          # src_app/
APP_ROOT: Path = BASE_DIR.parent                          # app.py/
PROJECT_DIR: Path = APP_ROOT.parent                       # predictive analysis/

MODELS_DIR: Path = BASE_DIR / "models"
ASSETS_DIR: Path = BASE_DIR / "assets"
REPORTS_DIR: Path = BASE_DIR / "reports"
PAGES_DIR: Path = BASE_DIR / "pages"

DATASET_PATH: Path = APP_ROOT / "data" / "predictive project dataset.csv"

# ═══════════════════════════════════════════════════
#  FEATURE CONFIGURATION
# ═══════════════════════════════════════════════════
NUMERIC_FEATURES: List[str] = [
    "NO_OF_ROAD_WORK_SANCTIONED",
    "NO_OF_BRIDGES_SANCTIONED",
    "NO_OF_ROAD_WORKS_COMPLETED",
    "NO_OF_BRIDGES_COMPLETED",
    "NO_OF_ROAD_WORKS_BALANCE",
    "NO_OF_BRIDGES_BALANCE",
    "LENGTH_OF_ROAD_WORK_SANCTIONED_KM",
    "COST_OF_WORKS_SANCTIONED_LAKHS",
    "LENGTH_OF_ROAD_WORK_COMPLETED_KM",
    "LENGTH_OF_ROAD_WORK_BALANCE_KM",
]

TARGET_COLUMN: str = "EXPENDITURE_OCCURED_LAKHS"

ALL_COLUMNS: List[str] = NUMERIC_FEATURES + [TARGET_COLUMN]

FEATURE_DESCRIPTIONS: Dict[str, str] = {
    "NO_OF_ROAD_WORK_SANCTIONED":       "Number of road works sanctioned",
    "NO_OF_BRIDGES_SANCTIONED":         "Number of bridges sanctioned",
    "NO_OF_ROAD_WORKS_COMPLETED":       "Number of road works completed",
    "NO_OF_BRIDGES_COMPLETED":          "Number of bridges completed",
    "NO_OF_ROAD_WORKS_BALANCE":         "Number of road works pending",
    "NO_OF_BRIDGES_BALANCE":            "Number of bridges pending",
    "LENGTH_OF_ROAD_WORK_SANCTIONED_KM":"Length of road work sanctioned (km)",
    "COST_OF_WORKS_SANCTIONED_LAKHS":   "Cost of works sanctioned (₹ Lakhs)",
    "LENGTH_OF_ROAD_WORK_COMPLETED_KM": "Length of road work completed (km)",
    "LENGTH_OF_ROAD_WORK_BALANCE_KM":   "Length of road work balance (km)",
    "EXPENDITURE_OCCURED_LAKHS":        "Expenditure occurred (₹ Lakhs)",
}

# ═══════════════════════════════════════════════════
#  MODEL TRAINING
# ═══════════════════════════════════════════════════
TEST_SIZE: float = 0.2
RANDOM_STATE: int = 42
CV_FOLDS: int = 5
POLYNOMIAL_DEGREE: int = 2
TUNING_N_ITER: int = 20          # iterations for RandomizedSearchCV
TUNING_SCORING: str = "r2"

# ═══════════════════════════════════════════════════
#  EXPENDITURE CATEGORIES
# ═══════════════════════════════════════════════════
EXPENDITURE_CATEGORIES: Dict[str, Tuple[float, float]] = {
    "Low":    (0,    500),
    "Medium": (500,  2000),
    "High":   (2000, float("inf")),
}

CATEGORY_COLORS: Dict[str, str] = {
    "Low":    "#10B981",   # Emerald
    "Medium": "#F59E0B",   # Amber
    "High":   "#EF4444",   # Red
}

CATEGORY_ICONS: Dict[str, str] = {
    "Low":    "✅",
    "Medium": "⚠️",
    "High":   "🔴",
}

# ═══════════════════════════════════════════════════
#  UI CONFIGURATION
# ═══════════════════════════════════════════════════
APP_TITLE: str = "🛣️ Road Infrastructure Expenditure Prediction System"
APP_ICON: str = "🛣️"
APP_SUBTITLE: str = "Predict road infrastructure expenditure using Machine Learning"
AUTHOR_NAME: str = "Ayush Gupta"
AUTHOR_ROLL: str = "12324198 | Roll No. 34"
APP_VERSION: str = "1.0.0"
MODEL_VERSION: str = "1.0.0"

# ── Color Palette (Modern dark-theme inspired) ───
COLORS: Dict[str, str] = {
    "primary":    "#6366F1",   # Indigo
    "secondary":  "#8B5CF6",   # Violet
    "accent":     "#EC4899",   # Pink
    "success":    "#10B981",   # Emerald
    "warning":    "#F59E0B",   # Amber
    "danger":     "#EF4444",   # Red
    "info":       "#3B82F6",   # Blue
    "background": "#0F172A",   # Slate-900
    "surface":    "#1E293B",   # Slate-800
    "text":       "#F8FAFC",   # Slate-50
    "muted":      "#94A3B8",   # Slate-400
}
